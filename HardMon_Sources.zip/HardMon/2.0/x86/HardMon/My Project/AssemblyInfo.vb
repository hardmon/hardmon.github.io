﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("HardMon")> 
<Assembly: AssemblyDescription("Real-Time Hardware Monitoring.")> 
<Assembly: AssemblyCompany("Ari Sohandri Putra")> 
<Assembly: AssemblyProduct("HardMon")> 
<Assembly: AssemblyCopyright("© 2025 Ari Sohandri Putra. All Rights Reserved.")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("b4be9b5d-22e4-417a-82d5-aa302ca3a752")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.506.12")> 
<Assembly: AssemblyFileVersion("1.0.506.12")> 
