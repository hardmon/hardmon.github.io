﻿Imports HardEngine
Imports System.Windows.Forms
Imports System.Threading
Imports System.Management
Imports System.IO
Imports System.Drawing.Drawing2D
Imports System.ComponentModel
Imports System.Diagnostics
Public Class Form1
    Dim stopwatch As Stopwatch
    Dim totalLoop As Integer = 100000000 ' default
    Dim testMode As String = "Math"
    Dim skorList As New List(Of KeyValuePair(Of String, Double))
    Dim testQueue As New Queue(Of String)
    Private monitor As Hardware
    Private updateThread As Thread
    Private stopThread As Boolean = False
    Private dataLock As New Object()
    Private latestData As New LatestMonitorData()
    Public mbManufacturer As String
    Public mbProduct As String
    Public mbSerial As String
    Public biosManufacturer As String
    Public biosVersion As String

    Private Class LatestMonitorData
        Public CPUInfo As List(Of Hardware.CPUInfo)
        Public GPUInfo As List(Of Hardware.GPUInfo)
        Public RAMInfo As List(Of Hardware.RAMInfo)
        Public HDDInfo As List(Of Hardware.HDDInfo)
        Public BatteryInfo As List(Of Hardware.BatteryInfo)
    End Class
    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            If Not DesignMode Then
                cp.ExStyle = cp.ExStyle Or &H2000000 ' WS_EX_COMPOSITED
                cp.ExStyle = cp.ExStyle Or &H80000 ' WS_EX_LAYERED (opsional)
            End If
            Return cp
        End Get
    End Property
    Sub setsizeView()
        If My.Settings.SetSize = "Default" Then
            Dim currentFont As Font = ZainView1.Font
            Dim newFontSize As Single = 9.0F ' Ubah sesuai keinginan

            ZainView1.Font = New Font(currentFont.FontFamily, newFontSize, currentFont.Style)
            DefaultToolStripMenuItem.Checked = True
            MediumToolStripMenuItem.Checked = False
            LargeToolStripMenuItem.Checked = False
        ElseIf My.Settings.SetSize = "Medium" Then
            Dim currentFont As Font = ZainView1.Font
            Dim newFontSize As Single = 11.0F ' Ubah sesuai keinginan

            ZainView1.Font = New Font(currentFont.FontFamily, newFontSize, currentFont.Style)
            DefaultToolStripMenuItem.Checked = False
            MediumToolStripMenuItem.Checked = True
            LargeToolStripMenuItem.Checked = False
        ElseIf My.Settings.SetSize = "Large" Then
            Dim currentFont As Font = ZainView1.Font
            Dim newFontSize As Single = 12.0F ' Ubah sesuai keinginan

            ZainView1.Font = New Font(currentFont.FontFamily, newFontSize, currentFont.Style)
            DefaultToolStripMenuItem.Checked = False
            MediumToolStripMenuItem.Checked = False
            LargeToolStripMenuItem.Checked = True
        Else
            Dim currentFont As Font = ZainView1.Font
            Dim newFontSize As Single = 9.0F ' Ubah sesuai keinginan

            ZainView1.Font = New Font(currentFont.FontFamily, newFontSize, currentFont.Style)
            DefaultToolStripMenuItem.Checked = True
            MediumToolStripMenuItem.Checked = False
            LargeToolStripMenuItem.Checked = False
        End If
    End Sub
    Sub setColorView()
        If My.Settings.SetColor = "Light" Then
            DefaultToolStripMenuItem1.Checked = True
            DarkToolStripMenuItem.Checked = False
            ZainView1.BackColor = Color.White
            ZainView1.ForeColor = Color.Black
            ZainView1.ImageList = ImageList1
        ElseIf My.Settings.SetColor = "Dark" Then
            DefaultToolStripMenuItem1.Checked = False
            DarkToolStripMenuItem.Checked = True
            ZainView1.BackColor = Color.FromArgb(70, 70, 70)
            ZainView1.ForeColor = Color.White
            ZainView1.ImageList = ImageList2
        Else
            DefaultToolStripMenuItem1.Checked = False
            DarkToolStripMenuItem.Checked = True
            ZainView1.BackColor = Color.FromArgb(70, 70, 70)
            ZainView1.ForeColor = Color.White
            ZainView1.ImageList = ImageList2
        End If
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "HardMon 1.0.50612"
        setColorView()
        setsizeView()
        monitor = New Hardware
        Timer1.Interval = 5000 ' Interval dalam milidetik (1000ms = 1 detik)
        Timer1.Start() ' Mulai timer
        refreshTimer.Interval = 1000 ' 1 second
        refreshTimer.Start()

        ' Start background thread for data collection
        updateThread = New Thread(AddressOf UpdateDataThread)
        updateThread.IsBackground = True
        updateThread.Start()
        ZainView1.HideSelection = True
    End Sub
    Private Sub UpdateDataThread()
        While Not stopThread
            Try
                ' Get fresh data
                Dim newData As New LatestMonitorData()
                monitor.Refresh()

                newData.CPUInfo = monitor.CPUInfos()
                newData.GPUInfo = monitor.GPUInfos()
                newData.RAMInfo = monitor.RAMInfos()
                newData.HDDInfo = monitor.HDDInfos()

                ' Update latest data in a thread-safe way
                SyncLock dataLock
                    latestData = newData
                End SyncLock

                ' Signal UI to update
                Me.Invoke(New MethodInvoker(AddressOf UpdateTreeViewNeeded))

                ' Sleep for a while before next update
                Thread.Sleep(1000) ' 1 seconds
            Catch ex As Exception
                ' Simple error handling - you might want to log this
                Debug.WriteLine("Update thread error: " & ex.Message)
            End Try
        End While
    End Sub

    Private Sub UpdateTreeViewNeeded()
        ' This method is called from the UI thread via Invoke
        If Not ZainView1.IsDisposed Then
            UpdateTreeView()
        End If
    End Sub

    Private Sub UpdateTreeView()
        ' Store current scroll position
        Dim scrollPos As Integer = GetScrollPosition()

        ' Store expanded state of nodes
        Dim expandedNodes As New Dictionary(Of String, Boolean)
        SaveExpandedState(ZainView1.Nodes, expandedNodes)

        ' Store selected node (if any)
        Dim selectedNodePath As String = If(ZainView1.SelectedNode IsNot Nothing, _
                                          GetNodePath(ZainView1.SelectedNode), _
                                          String.Empty)

        ' Clear existing nodes
        ZainView1.BeginUpdate()
        ZainView1.Nodes.Clear()

        ' Add new nodes with latest data
        SyncLock dataLock
            ' System Info
            Dim searcher As New ManagementObjectSearcher("SELECT * FROM Win32_BaseBoard")

            For Each obj As ManagementObject In searcher.Get()
                Dim manufacturer As String = obj("Manufacturer").ToString()
                Dim product As String = obj("Product").ToString()
                mbManufacturer = manufacturer
                mbProduct = product
            Next
            Dim searcher1 As New ManagementObjectSearcher("SELECT * FROM Win32_BIOS")

            For Each obj As ManagementObject In searcher1.Get()
                Dim manufacturers As String = obj("Manufacturer").ToString()
                Dim versions As String = obj("SMBIOSBIOSVersion").ToString()
                biosManufacturer = manufacturers
                biosVersion = versions
            Next
            Dim systemNode As TreeNode = ZainView1.Nodes.Add(mbManufacturer & " (" & mbProduct & ")")
            systemNode.ImageIndex = 15
            systemNode.SelectedImageIndex = 15
            Dim systmnamenode As TreeNode = systemNode.Nodes.Add(biosManufacturer & "(" & biosVersion & ")")
            systmnamenode.ImageIndex = 16
            systmnamenode.SelectedImageIndex = 16
            Me.Text = "HardMon - [" & mbManufacturer & " (" & mbProduct & ")" & "]"
            ' CPU Information
            If latestData.CPUInfo IsNot Nothing AndAlso latestData.CPUInfo.Count > 0 Then

                For Each cpu In latestData.CPUInfo
                    Dim cpuNameNode As TreeNode = ZainView1.Nodes.Add(cpu.Name)
                    Dim cpuname As String = cpu.Name.ToLower

                    If cpuName.Contains("intel") Then
                        cpuNameNode.ImageIndex = 2
                        cpuNameNode.SelectedImageIndex = 2
                    ElseIf cpuName.Contains("amd") Then
                        cpuNameNode.ImageIndex = 3
                        cpuNameNode.SelectedImageIndex = 3
                    Else
                        cpuNameNode.ImageIndex = 1
                        cpuNameNode.SelectedImageIndex = 1
                    End If
                    ' Add CPU Clock
                    If cpu.Clock.Count > 0 Then
                        Dim clockNode As TreeNode = cpuNameNode.Nodes.Add("Clock")
                        clockNode.ImageIndex = 4
                        clockNode.SelectedImageIndex = 4
                        For Each clock In cpu.Clock
                            Dim subClockNode As TreeNode = clockNode.Nodes.Add(clock)
                        Next
                    End If

                    ' Add CPU Load
                    If cpu.Load.Count > 0 Then
                        Dim loadNode As TreeNode = cpuNameNode.Nodes.Add("Load")
                        loadNode.ImageIndex = 5
                        loadNode.SelectedImageIndex = 5
                        For Each loads In cpu.Load
                            loadNode.Nodes.Add(loads)
                        Next
                    End If

                    ' Add CPU Temperature
                    If cpu.Temperature.Count > 0 Then
                        Dim tempNode As TreeNode = cpuNameNode.Nodes.Add("Temperature")
                        tempNode.ImageIndex = 6
                        tempNode.SelectedImageIndex = 6
                        For Each temp In cpu.Temperature
                            tempNode.Nodes.Add(temp)
                        Next
                    End If

                    ' Add CPU Power
                    If cpu.Power.Count > 0 Then
                        Dim powerNode As TreeNode = cpuNameNode.Nodes.Add("Power")
                        powerNode.ImageIndex = 7
                        powerNode.SelectedImageIndex = 7
                        For Each power In cpu.Power
                            powerNode.Nodes.Add(power)
                        Next
                    End If
                Next
            End If

            ' GPU Information
            If latestData.GPUInfo IsNot Nothing AndAlso latestData.GPUInfo.Count > 0 Then
                For Each gpu In latestData.GPUInfo
                    Dim gpuNameNode As TreeNode = ZainView1.Nodes.Add(gpu.Name)
                    Dim gpuname As String = gpu.Name.ToLower
                    If gpuname.Contains("amd") Then
                        gpuNameNode.ImageIndex = 10
                        gpuNameNode.SelectedImageIndex = 10
                    ElseIf gpuname.Contains("radeon") Then
                        gpuNameNode.ImageIndex = 10
                        gpuNameNode.SelectedImageIndex = 10
                    ElseIf gpuname.Contains("nvidia") Then
                        gpuNameNode.ImageIndex = 9
                        gpuNameNode.SelectedImageIndex = 9
                    ElseIf gpuname.Contains("rtx") Then
                        gpuNameNode.ImageIndex = 9
                        gpuNameNode.SelectedImageIndex = 9
                    ElseIf gpuname.Contains("gtx") Then
                        gpuNameNode.ImageIndex = 9
                        gpuNameNode.SelectedImageIndex = 9
                    Else
                        gpuNameNode.ImageIndex = 8
                        gpuNameNode.SelectedImageIndex = 8
                    End If
                    ' Add GPU Load
                    If gpu.Load.Count > 0 Then
                        Dim loadNode As TreeNode = gpuNameNode.Nodes.Add("Load")
                        loadNode.ImageIndex = 5
                        loadNode.SelectedImageIndex = 5
                        For Each loads In gpu.Load
                            loadNode.Nodes.Add(loads)
                        Next
                    End If

                    ' Add GPU Temperature
                    If gpu.Temperature.Count > 0 Then
                        Dim tempNode As TreeNode = gpuNameNode.Nodes.Add("Temperature")
                        tempNode.ImageIndex = 6
                        tempNode.SelectedImageIndex = 6
                        For Each temp In gpu.Temperature
                            tempNode.Nodes.Add(temp)
                        Next
                    End If

                    ' Add GPU Clock
                    If gpu.Clock.Count > 0 Then
                        Dim clockNode As TreeNode = gpuNameNode.Nodes.Add("Clock")
                        clockNode.ImageIndex = 4
                        clockNode.SelectedImageIndex = 4
                        For Each clock In gpu.Clock
                            clockNode.Nodes.Add(clock)
                        Next
                    End If

                    ' Add GPU Memory
                    If gpu.Memory.Count > 0 Then
                        Dim memoryNode As TreeNode = gpuNameNode.Nodes.Add("Memory")
                        memoryNode.ImageIndex = 12
                        memoryNode.SelectedImageIndex = 12
                        For Each memory In gpu.Memory
                            memoryNode.Nodes.Add(memory)
                        Next
                    End If
                Next
            End If

            ' RAM Information
            If latestData.RAMInfo IsNot Nothing AndAlso latestData.RAMInfo.Count > 0 Then
                For Each ram In latestData.RAMInfo
                    Dim ramNameNode As TreeNode = ZainView1.Nodes.Add(ram.Name)
                    ramNameNode.ImageIndex = 12
                    ramNameNode.SelectedImageIndex = 12
                    ' Add RAM Load
                    If ram.Load.Count > 0 Then
                        Dim loadNode As TreeNode = ramNameNode.Nodes.Add("Load")
                        loadNode.ImageIndex = 5
                        loadNode.SelectedImageIndex = 5
                        For Each loads In ram.Load
                            loadNode.Nodes.Add(loads)
                        Next
                    End If

                    ' Add RAM Usage
                    If ram.Used.Count > 0 Then
                        Dim usageNode As TreeNode = ramNameNode.Nodes.Add("Usage")
                        usageNode.ImageIndex = 13
                        usageNode.SelectedImageIndex = 13
                        For Each used In ram.Used
                            usageNode.Nodes.Add(used)
                        Next
                        For Each avail In ram.Available
                            usageNode.Nodes.Add(avail)
                        Next
                        For Each total In ram.Total
                            usageNode.Nodes.Add(total)
                        Next
                    End If
                Next
            End If

            ' HDD Information
            If latestData.HDDInfo IsNot Nothing AndAlso latestData.HDDInfo.Count > 0 Then
                For Each hdd In latestData.HDDInfo
                    Dim hddNameNode As TreeNode = ZainView1.Nodes.Add(hdd.Name)
                    hddNameNode.ImageIndex = 11
                    hddNameNode.SelectedImageIndex = 11
                    ' Add HDD Temperature
                    If hdd.Temperature.Count > 0 Then
                        Dim tempNode As TreeNode = hddNameNode.Nodes.Add("Temperature")
                        tempNode.ImageIndex = 6
                        tempNode.SelectedImageIndex = 6
                        For Each temp In hdd.Temperature
                            tempNode.Nodes.Add(temp)
                        Next
                    End If

                    ' Add HDD Usage
                    If hdd.Load.Count > 0 Then
                        Dim usageNode As TreeNode = hddNameNode.Nodes.Add("Usage")
                        usageNode.ImageIndex = 13
                        usageNode.SelectedImageIndex = 13
                        For Each loads In hdd.Load
                            usageNode.Nodes.Add(loads)
                        Next
                    End If

                    ' Add HDD Throughput
                    If hdd.Throughput.Count > 0 Then
                        Dim throughputNode As TreeNode = hddNameNode.Nodes.Add("Throughput")
                        throughputNode.ImageIndex = 14
                        throughputNode.SelectedImageIndex = 14
                        For Each throughput In hdd.Throughput
                            throughputNode.Nodes.Add(throughput)
                        Next
                    End If
                Next
            End If
        End SyncLock

        ' Restore expanded state
        RestoreExpandedState(ZainView1.Nodes, expandedNodes)

        ' Restore selected node (if it still exists)
        If Not String.IsNullOrEmpty(selectedNodePath) Then
            Dim nodeToSelect As TreeNode = FindNodeByPath(ZainView1.Nodes, selectedNodePath)
            If nodeToSelect IsNot Nothing Then
                ZainView1.SelectedNode = nodeToSelect
            End If
        End If

        ZainView1.ExpandAll()

        SetScrollPosition(scrollPos)
        ZainView1.EndUpdate()
    End Sub

    ' Helper methods for TreeView state management
    Private Sub SaveExpandedState(ByVal nodes As TreeNodeCollection, ByRef expandedNodes As Dictionary(Of String, Boolean))
        For Each node As TreeNode In nodes
            expandedNodes(GetNodePath(node)) = node.IsExpanded
            If node.Nodes.Count > 0 Then
                SaveExpandedState(node.Nodes, expandedNodes)
            End If
        Next
    End Sub

    Private Sub RestoreExpandedState(ByVal nodes As TreeNodeCollection, ByVal expandedNodes As Dictionary(Of String, Boolean))
        For Each node As TreeNode In nodes
            Dim path As String = GetNodePath(node)
            If expandedNodes.ContainsKey(path) AndAlso expandedNodes(path) Then
                node.Expand()
            End If
            If node.Nodes.Count > 0 Then
                RestoreExpandedState(node.Nodes, expandedNodes)
            End If
        Next
    End Sub

    Private Function GetNodePath(ByVal node As TreeNode) As String
        Dim path As String = node.Text
        Dim parent As TreeNode = node.Parent
        While parent IsNot Nothing
            path = parent.Text & "/" & path
            parent = parent.Parent
        End While
        Return path
    End Function

    Private Function FindNodeByPath(ByVal nodes As TreeNodeCollection, ByVal path As String) As TreeNode
        Dim parts() As String = path.Split("/"c)
        If parts.Length = 0 Then Return Nothing

        Dim currentNodes As TreeNodeCollection = nodes
        Dim foundNode As TreeNode = Nothing

        For Each part As String In parts
            foundNode = Nothing
            For Each node As TreeNode In currentNodes
                If node.Text = part Then
                    foundNode = node
                    currentNodes = node.Nodes
                    Exit For
                End If
            Next
            If foundNode Is Nothing Then Exit For
        Next

        Return foundNode
    End Function


    Private Declare Auto Function GetScrollPos Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal nBar As Integer) As Integer
    Private Declare Auto Function SetScrollPos Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal nBar As Integer, ByVal nPos As Integer, ByVal bRedraw As Boolean) As Integer
    Private Declare Auto Function SendMessage Lib "user32.dll" Alias "SendMessageA" (ByVal hWnd As IntPtr, ByVal msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer

    Private Const WM_VSCROLL As Integer = &H115
    Private Const SB_THUMBPOSITION As Integer = 4
    Private Const SB_VERT As Integer = 1

    Private Function GetScrollPosition() As Integer
        Return GetScrollPos(ZainView1.Handle, SB_VERT)
    End Function

    Private Sub SetScrollPosition(ByVal position As Integer)
        SetScrollPos(ZainView1.Handle, SB_VERT, position, True)
        SendMessage(ZainView1.Handle, WM_VSCROLL, SB_THUMBPOSITION + &H10000 * position, 0)
    End Sub

    Private Sub refreshTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles refreshTimer.Tick
        UpdateTreeViewNeeded()
    End Sub

    Private Sub DarkToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DarkToolStripMenuItem.Click
        DefaultToolStripMenuItem1.Checked = False
        DarkToolStripMenuItem.Checked = True
        ZainView1.BackColor = Color.FromArgb(70, 70, 70)
        ZainView1.ForeColor = Color.White
        ZainView1.ImageList = ImageList2
        My.Settings.SetColor = "Dark"
        My.Settings.Save()
    End Sub

    Private Sub DefaultToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultToolStripMenuItem1.Click
        DefaultToolStripMenuItem1.Checked = True
        DarkToolStripMenuItem.Checked = False
        ZainView1.BackColor = Color.White
        ZainView1.ForeColor = Color.Black
        ZainView1.ImageList = ImageList1
        My.Settings.SetColor = "Light"
        My.Settings.Save()
    End Sub

    Private Sub DefaultToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultToolStripMenuItem.Click
        Dim currentFont As Font = ZainView1.Font
        Dim newFontSize As Single = 9.0F ' Ubah sesuai keinginan

        ZainView1.Font = New Font(currentFont.FontFamily, newFontSize, currentFont.Style)
        DefaultToolStripMenuItem.Checked = True
        MediumToolStripMenuItem.Checked = False
        LargeToolStripMenuItem.Checked = False
        My.Settings.SetSize = "Default"
        My.Settings.Save()
    End Sub

    Private Sub MediumToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MediumToolStripMenuItem.Click
        Dim currentFont As Font = ZainView1.Font
        Dim newFontSize As Single = 11.0F ' Ubah sesuai keinginan

        ZainView1.Font = New Font(currentFont.FontFamily, newFontSize, currentFont.Style)
        DefaultToolStripMenuItem.Checked = False
        MediumToolStripMenuItem.Checked = True
        LargeToolStripMenuItem.Checked = False
        My.Settings.SetSize = "Medium"
        My.Settings.Save()
    End Sub

    Private Sub LargeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LargeToolStripMenuItem.Click
        Dim currentFont As Font = ZainView1.Font
        Dim newFontSize As Single = 12.0F ' Ubah sesuai keinginan

        ZainView1.Font = New Font(currentFont.FontFamily, newFontSize, currentFont.Style)
        DefaultToolStripMenuItem.Checked = False
        MediumToolStripMenuItem.Checked = False
        LargeToolStripMenuItem.Checked = True
        My.Settings.SetSize = "Large"
        My.Settings.Save()
    End Sub
    Dim teksArray() As String = {"Dark Themes (CTRL + D) /or Light Themes (CTRL + L)", "Set Monitor Size (CTRL + SHIFT + D/M/L)"}
    Dim indeks As Integer = 0
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ' Ubah teks label berdasarkan array
        lbtip.Text = teksArray(indeks)

        ' Lanjut ke indeks berikutnya
        indeks += 1
        If indeks >= teksArray.Length Then
            indeks = 0 ' Kembali ke awal
        End If
    End Sub

    Private Sub AboutHardMonToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutHardMonToolStripMenuItem.Click
        frmAbout.Show()
    End Sub

    Private Sub ZainView1_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles ZainView1.AfterSelect
        Me.ActiveControl = Nothing
    End Sub

    Private Sub ZainView1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ZainView1.Click
        Me.ActiveControl = Nothing
    End Sub
    Private Sub SaveTreeViewToFile(ByVal treeView As TreeView, ByVal filePath As String)
        Using writer As New System.IO.StreamWriter(filePath)
            For Each node As TreeNode In treeView.Nodes
                WriteNodeToFile(node, writer, 0)
            Next
        End Using
    End Sub

    Private Sub WriteNodeToFile(ByVal node As TreeNode, ByVal writer As System.IO.StreamWriter, ByVal indentLevel As Integer)
        writer.WriteLine(New String(" "c, indentLevel * 2) & node.Text)
        For Each childNode As TreeNode In node.Nodes
            WriteNodeToFile(childNode, writer, indentLevel + 1)
        Next
    End Sub

    Private Sub SaveMonitoringDataToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveMonitoringDataToolStripMenuItem.Click
        Dim saveFileDialog As New SaveFileDialog()
        saveFileDialog.Filter = "Text Files (*.txt)|*.txt"
        saveFileDialog.Title = "Save Monitoring Data"
        saveFileDialog.FileName = "HardMon_" & DateTime.Now.ToString("yyyy-MM-dd-hhmmss")
        If saveFileDialog.ShowDialog() = DialogResult.OK Then
            SaveTreeViewToFile(ZainView1, saveFileDialog.FileName)
            MessageBox.Show("Monitoring data is saved to " & saveFileDialog.FileName, "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub UserGuideToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UserGuideToolStripMenuItem.Click
        Try
            Process.Start("https://hardmon.github.io/guide.html")
        Catch ex As Exception
            '
        End Try
    End Sub
End Class
