﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWCPU
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lbcpu = New System.Windows.Forms.Label()
        Me.lbclock = New System.Windows.Forms.Label()
        Me.lbtemp = New System.Windows.Forms.Label()
        Me.lbpower = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.lbram = New System.Windows.Forms.Label()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.lbhdd = New System.Windows.Forms.Label()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.lbnet = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitWidgetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutHardMonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AlwaysOnTopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Enabled = False
        Me.PictureBox1.Location = New System.Drawing.Point(2, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lbcpu
        '
        Me.lbcpu.BackColor = System.Drawing.Color.Beige
        Me.lbcpu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbcpu.Enabled = False
        Me.lbcpu.Location = New System.Drawing.Point(24, 3)
        Me.lbcpu.Name = "lbcpu"
        Me.lbcpu.Size = New System.Drawing.Size(258, 16)
        Me.lbcpu.TabIndex = 1
        Me.lbcpu.Text = "-"
        '
        'lbclock
        '
        Me.lbclock.BackColor = System.Drawing.Color.Beige
        Me.lbclock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbclock.Enabled = False
        Me.lbclock.Location = New System.Drawing.Point(24, 19)
        Me.lbclock.Name = "lbclock"
        Me.lbclock.Size = New System.Drawing.Size(115, 16)
        Me.lbclock.TabIndex = 3
        Me.lbclock.Text = "-"
        '
        'lbtemp
        '
        Me.lbtemp.BackColor = System.Drawing.Color.Beige
        Me.lbtemp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbtemp.Enabled = False
        Me.lbtemp.Location = New System.Drawing.Point(167, 19)
        Me.lbtemp.Name = "lbtemp"
        Me.lbtemp.Size = New System.Drawing.Size(115, 16)
        Me.lbtemp.TabIndex = 7
        Me.lbtemp.Text = "-"
        '
        'lbpower
        '
        Me.lbpower.BackColor = System.Drawing.Color.Beige
        Me.lbpower.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbpower.Enabled = False
        Me.lbpower.Location = New System.Drawing.Point(24, 34)
        Me.lbpower.Name = "lbpower"
        Me.lbpower.Size = New System.Drawing.Size(115, 16)
        Me.lbpower.TabIndex = 12
        Me.lbpower.Text = "-"
        '
        'PictureBox2
        '
        Me.PictureBox2.Enabled = False
        Me.PictureBox2.Location = New System.Drawing.Point(2, 19)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 13
        Me.PictureBox2.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Enabled = False
        Me.PictureBox4.Location = New System.Drawing.Point(145, 19)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox4.TabIndex = 15
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Enabled = False
        Me.PictureBox5.Location = New System.Drawing.Point(2, 34)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox5.TabIndex = 16
        Me.PictureBox5.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Enabled = False
        Me.PictureBox3.Location = New System.Drawing.Point(145, 34)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox3.TabIndex = 18
        Me.PictureBox3.TabStop = False
        '
        'lbram
        '
        Me.lbram.BackColor = System.Drawing.Color.Beige
        Me.lbram.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbram.Enabled = False
        Me.lbram.Location = New System.Drawing.Point(167, 34)
        Me.lbram.Name = "lbram"
        Me.lbram.Size = New System.Drawing.Size(115, 16)
        Me.lbram.TabIndex = 17
        Me.lbram.Text = "-"
        '
        'PictureBox6
        '
        Me.PictureBox6.Enabled = False
        Me.PictureBox6.Location = New System.Drawing.Point(2, 50)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox6.TabIndex = 20
        Me.PictureBox6.TabStop = False
        '
        'lbhdd
        '
        Me.lbhdd.BackColor = System.Drawing.Color.Beige
        Me.lbhdd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbhdd.Enabled = False
        Me.lbhdd.Location = New System.Drawing.Point(24, 50)
        Me.lbhdd.Name = "lbhdd"
        Me.lbhdd.Size = New System.Drawing.Size(115, 16)
        Me.lbhdd.TabIndex = 19
        Me.lbhdd.Text = "-"
        '
        'PictureBox7
        '
        Me.PictureBox7.Enabled = False
        Me.PictureBox7.Location = New System.Drawing.Point(145, 50)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox7.TabIndex = 22
        Me.PictureBox7.TabStop = False
        '
        'lbnet
        '
        Me.lbnet.BackColor = System.Drawing.Color.Beige
        Me.lbnet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbnet.Enabled = False
        Me.lbnet.Location = New System.Drawing.Point(167, 50)
        Me.lbnet.Name = "lbnet"
        Me.lbnet.Size = New System.Drawing.Size(115, 16)
        Me.lbnet.TabIndex = 21
        Me.lbnet.Text = "-"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Enabled = False
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(2, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(267, 13)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Right-click anywhere on the widget to open the menu."
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitWidgetToolStripMenuItem, Me.ToolStripSeparator1, Me.AlwaysOnTopToolStripMenuItem, Me.ToolStripSeparator2, Me.AboutHardMonToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(162, 82)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(158, 6)
        '
        'ExitWidgetToolStripMenuItem
        '
        Me.ExitWidgetToolStripMenuItem.Name = "ExitWidgetToolStripMenuItem"
        Me.ExitWidgetToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.ExitWidgetToolStripMenuItem.Text = "Close Widget"
        '
        'AboutHardMonToolStripMenuItem
        '
        Me.AboutHardMonToolStripMenuItem.Name = "AboutHardMonToolStripMenuItem"
        Me.AboutHardMonToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.AboutHardMonToolStripMenuItem.Text = "About HardMon"
        '
        'AlwaysOnTopToolStripMenuItem
        '
        Me.AlwaysOnTopToolStripMenuItem.Checked = True
        Me.AlwaysOnTopToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.AlwaysOnTopToolStripMenuItem.Name = "AlwaysOnTopToolStripMenuItem"
        Me.AlwaysOnTopToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.AlwaysOnTopToolStripMenuItem.Text = "Always on top"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(158, 6)
        '
        'frmWCPU
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.ClientSize = New System.Drawing.Size(283, 85)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.lbnet)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.lbhdd)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.lbram)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.lbpower)
        Me.Controls.Add(Me.lbtemp)
        Me.Controls.Add(Me.lbclock)
        Me.Controls.Add(Me.lbcpu)
        Me.Controls.Add(Me.PictureBox1)
        Me.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmWCPU"
        Me.Opacity = 0.98R
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lbcpu As System.Windows.Forms.Label
    Friend WithEvents lbclock As System.Windows.Forms.Label
    Friend WithEvents lbtemp As System.Windows.Forms.Label
    Friend WithEvents lbpower As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents lbram As System.Windows.Forms.Label
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents lbhdd As System.Windows.Forms.Label
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents lbnet As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitWidgetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutHardMonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AlwaysOnTopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
End Class
