﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("HardMon")> 
<Assembly: AssemblyDescription("Real-time hardware monitoring tool.")> 
<Assembly: AssemblyCompany("Ari Sohandri Putra")> 
<Assembly: AssemblyProduct("HardMon")> 
<Assembly: AssemblyCopyright("© 2025 Ari Sohandri Putra. All rights reserved.")> 
<Assembly: AssemblyTrademark("HardMon")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("c43ca120-af4d-46fe-bc28-4ab3e763e6d7")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("2.0.0.0")> 
<Assembly: AssemblyFileVersion("2.0.0.0")> 
