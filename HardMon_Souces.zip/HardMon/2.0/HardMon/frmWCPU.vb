﻿Public Class frmWCPU
    Dim mouseOffset As Point
    Dim isMouseDown As Boolean = False
    Private Sub frmWCPU_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim screenArea As Rectangle = Screen.PrimaryScreen.WorkingArea
        Me.Location = New Point(screenArea.Right - Me.Width, screenArea.Bottom - Me.Height)
        PictureBox1.Image = Form1.ImageList1.Images(3)
        PictureBox2.Image = Form1.ImageList1.Images(4)
        PictureBox4.Image = Form1.ImageList1.Images(6)
        PictureBox5.Image = Form1.ImageList1.Images(7)
        PictureBox3.Image = Form1.ImageList1.Images(11)
        PictureBox6.Image = Form1.ImageList1.Images(13)
        PictureBox7.Image = Form1.ImageList1.Images(21)
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub frmWCPU_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        If e.Button = MouseButtons.Left Then
            mouseOffset = New Point(-e.X, -e.Y)
            isMouseDown = True
        ElseIf e.Button = MouseButtons.Right Then
            ContextMenuStrip1.Show(Me, e.Location)
        End If
    End Sub

    Private Sub frmWCPU_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove
        If isMouseDown Then
            Dim mousePos As Point = Control.MousePosition
            mousePos.Offset(mouseOffset.X, mouseOffset.Y)
            Me.Location = mousePos
            Me.Cursor = Cursors.NoMove2D
        End If
    End Sub

    Private Sub frmWCPU_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseUp
        If e.Button = MouseButtons.Left Then
            isMouseDown = False
            Me.Cursor = Cursors.Default
        End If
    End Sub

    Private Sub ExitWidgetToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitWidgetToolStripMenuItem.Click
        widget = False
        Form1.WidgetToolStripMenuItem.Checked = False
        Form1.Show()
        Me.Close()
    End Sub

    Private Sub ToolStripSeparator1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripSeparator1.Click

    End Sub

    Private Sub AboutHardMonToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutHardMonToolStripMenuItem.Click
        frmAbout.Show()
    End Sub

    Private Sub AlwaysOnTopToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AlwaysOnTopToolStripMenuItem.Click
        If AlwaysOnTopToolStripMenuItem.Checked Then
            Me.TopMost = False
            AlwaysOnTopToolStripMenuItem.Checked = False
        Else
            Me.TopMost = True
            AlwaysOnTopToolStripMenuItem.Checked = True
        End If
    End Sub
End Class