﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MainMenu = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveMonitoringData = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DarkModeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WidgetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.AlwaysOnTopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MonitoringToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CPUToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GPUToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RAMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HDDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NetworkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BatteryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AudioDeviceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ShowAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HardMonSDKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.LbLogStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Tema = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ZainView1 = New ZainView.ZainView()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.ImageList2 = New System.Windows.Forms.ImageList(Me.components)
        Me.refreshTimer = New System.Windows.Forms.Timer(Me.components)
        Me.MainMenu.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MainMenu
        '
        Me.MainMenu.BackColor = System.Drawing.Color.White
        Me.MainMenu.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ViewToolStripMenuItem, Me.MonitoringToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MainMenu.Location = New System.Drawing.Point(0, 0)
        Me.MainMenu.Name = "MainMenu"
        Me.MainMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MainMenu.Size = New System.Drawing.Size(586, 24)
        Me.MainMenu.TabIndex = 0
        Me.MainMenu.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveMonitoringData, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'SaveMonitoringData
        '
        Me.SaveMonitoringData.Image = Global.HardMon.My.Resources.Resources.icon_save
        Me.SaveMonitoringData.Name = "SaveMonitoringData"
        Me.SaveMonitoringData.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveMonitoringData.Size = New System.Drawing.Size(228, 22)
        Me.SaveMonitoringData.Text = "Save Monitoring Data"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(225, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(228, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DarkModeToolStripMenuItem, Me.WidgetToolStripMenuItem, Me.ToolStripSeparator2, Me.AlwaysOnTopToolStripMenuItem})
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ViewToolStripMenuItem.Text = "&View"
        '
        'DarkModeToolStripMenuItem
        '
        Me.DarkModeToolStripMenuItem.Image = Global.HardMon.My.Resources.Resources.icon_dark
        Me.DarkModeToolStripMenuItem.Name = "DarkModeToolStripMenuItem"
        Me.DarkModeToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.DarkModeToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.DarkModeToolStripMenuItem.Text = "Dark Mode"
        '
        'WidgetToolStripMenuItem
        '
        Me.WidgetToolStripMenuItem.Image = Global.HardMon.My.Resources.Resources.icon_widget
        Me.WidgetToolStripMenuItem.Name = "WidgetToolStripMenuItem"
        Me.WidgetToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.W), System.Windows.Forms.Keys)
        Me.WidgetToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.WidgetToolStripMenuItem.Text = "Widget"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(209, 6)
        '
        'AlwaysOnTopToolStripMenuItem
        '
        Me.AlwaysOnTopToolStripMenuItem.Name = "AlwaysOnTopToolStripMenuItem"
        Me.AlwaysOnTopToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Alt) _
                    Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.AlwaysOnTopToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.AlwaysOnTopToolStripMenuItem.Text = "Always on top"
        '
        'MonitoringToolStripMenuItem
        '
        Me.MonitoringToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CPUToolStripMenuItem, Me.GPUToolStripMenuItem, Me.RAMToolStripMenuItem, Me.HDDToolStripMenuItem, Me.NetworkToolStripMenuItem, Me.BatteryToolStripMenuItem, Me.AudioDeviceToolStripMenuItem, Me.ToolStripSeparator3, Me.ShowAllToolStripMenuItem})
        Me.MonitoringToolStripMenuItem.Name = "MonitoringToolStripMenuItem"
        Me.MonitoringToolStripMenuItem.Size = New System.Drawing.Size(79, 20)
        Me.MonitoringToolStripMenuItem.Text = "&Monitoring"
        '
        'CPUToolStripMenuItem
        '
        Me.CPUToolStripMenuItem.Checked = True
        Me.CPUToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CPUToolStripMenuItem.Enabled = False
        Me.CPUToolStripMenuItem.Name = "CPUToolStripMenuItem"
        Me.CPUToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.CPUToolStripMenuItem.Text = "CPU"
        '
        'GPUToolStripMenuItem
        '
        Me.GPUToolStripMenuItem.Checked = True
        Me.GPUToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.GPUToolStripMenuItem.Enabled = False
        Me.GPUToolStripMenuItem.Name = "GPUToolStripMenuItem"
        Me.GPUToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.GPUToolStripMenuItem.Text = "GPU"
        '
        'RAMToolStripMenuItem
        '
        Me.RAMToolStripMenuItem.Checked = True
        Me.RAMToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.RAMToolStripMenuItem.Enabled = False
        Me.RAMToolStripMenuItem.Name = "RAMToolStripMenuItem"
        Me.RAMToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.RAMToolStripMenuItem.Text = "RAM"
        '
        'HDDToolStripMenuItem
        '
        Me.HDDToolStripMenuItem.Checked = True
        Me.HDDToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.HDDToolStripMenuItem.Enabled = False
        Me.HDDToolStripMenuItem.Name = "HDDToolStripMenuItem"
        Me.HDDToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.HDDToolStripMenuItem.Text = "HDD"
        '
        'NetworkToolStripMenuItem
        '
        Me.NetworkToolStripMenuItem.Checked = True
        Me.NetworkToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.NetworkToolStripMenuItem.Enabled = False
        Me.NetworkToolStripMenuItem.Name = "NetworkToolStripMenuItem"
        Me.NetworkToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.NetworkToolStripMenuItem.Text = "Network"
        '
        'BatteryToolStripMenuItem
        '
        Me.BatteryToolStripMenuItem.Checked = True
        Me.BatteryToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.BatteryToolStripMenuItem.Enabled = False
        Me.BatteryToolStripMenuItem.Name = "BatteryToolStripMenuItem"
        Me.BatteryToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.BatteryToolStripMenuItem.Text = "Battery"
        '
        'AudioDeviceToolStripMenuItem
        '
        Me.AudioDeviceToolStripMenuItem.Checked = True
        Me.AudioDeviceToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.AudioDeviceToolStripMenuItem.Enabled = False
        Me.AudioDeviceToolStripMenuItem.Name = "AudioDeviceToolStripMenuItem"
        Me.AudioDeviceToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.AudioDeviceToolStripMenuItem.Text = "Audio Device"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(141, 6)
        '
        'ShowAllToolStripMenuItem
        '
        Me.ShowAllToolStripMenuItem.Checked = True
        Me.ShowAllToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ShowAllToolStripMenuItem.Name = "ShowAllToolStripMenuItem"
        Me.ShowAllToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.ShowAllToolStripMenuItem.Text = "Show All"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HardMonSDKToolStripMenuItem, Me.ToolStripSeparator5, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'HardMonSDKToolStripMenuItem
        '
        Me.HardMonSDKToolStripMenuItem.Image = Global.HardMon.My.Resources.Resources.chm_0
        Me.HardMonSDKToolStripMenuItem.Name = "HardMonSDKToolStripMenuItem"
        Me.HardMonSDKToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.HardMonSDKToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.HardMonSDKToolStripMenuItem.Text = "HardMon SDK Documentation"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(251, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Image = Global.HardMon.My.Resources.Resources.icon_about
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.White
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LbLogStatus, Me.Tema})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 535)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(586, 22)
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'LbLogStatus
        '
        Me.LbLogStatus.Enabled = False
        Me.LbLogStatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LbLogStatus.Name = "LbLogStatus"
        Me.LbLogStatus.Size = New System.Drawing.Size(161, 17)
        Me.LbLogStatus.Text = "HardMon 2.0 Build (06/27/2025)"
        '
        'Tema
        '
        Me.Tema.Name = "Tema"
        Me.Tema.Size = New System.Drawing.Size(34, 17)
        Me.Tema.Text = "tema"
        Me.Tema.Visible = False
        '
        'ZainView1
        '
        Me.ZainView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ZainView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ZainView1.Font = New System.Drawing.Font("Consolas", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZainView1.Location = New System.Drawing.Point(0, 24)
        Me.ZainView1.Name = "ZainView1"
        Me.ZainView1.Size = New System.Drawing.Size(586, 511)
        Me.ZainView1.TabIndex = 2
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "0.png")
        Me.ImageList1.Images.SetKeyName(1, "1.png")
        Me.ImageList1.Images.SetKeyName(2, "2.png")
        Me.ImageList1.Images.SetKeyName(3, "3.png")
        Me.ImageList1.Images.SetKeyName(4, "4.png")
        Me.ImageList1.Images.SetKeyName(5, "5.png")
        Me.ImageList1.Images.SetKeyName(6, "6.png")
        Me.ImageList1.Images.SetKeyName(7, "7.png")
        Me.ImageList1.Images.SetKeyName(8, "8.png")
        Me.ImageList1.Images.SetKeyName(9, "9.png")
        Me.ImageList1.Images.SetKeyName(10, "10.png")
        Me.ImageList1.Images.SetKeyName(11, "11.png")
        Me.ImageList1.Images.SetKeyName(12, "12.png")
        Me.ImageList1.Images.SetKeyName(13, "13.png")
        Me.ImageList1.Images.SetKeyName(14, "14.png")
        Me.ImageList1.Images.SetKeyName(15, "15.png")
        Me.ImageList1.Images.SetKeyName(16, "16.png")
        Me.ImageList1.Images.SetKeyName(17, "17.png")
        Me.ImageList1.Images.SetKeyName(18, "18.png")
        Me.ImageList1.Images.SetKeyName(19, "19.png")
        Me.ImageList1.Images.SetKeyName(20, "20.png")
        Me.ImageList1.Images.SetKeyName(21, "21.png")
        Me.ImageList1.Images.SetKeyName(22, "22.png")
        Me.ImageList1.Images.SetKeyName(23, "23.png")
        Me.ImageList1.Images.SetKeyName(24, "24.png")
        Me.ImageList1.Images.SetKeyName(25, "25.png")
        Me.ImageList1.Images.SetKeyName(26, "26.png")
        Me.ImageList1.Images.SetKeyName(27, "27.png")
        Me.ImageList1.Images.SetKeyName(28, "28.png")
        Me.ImageList1.Images.SetKeyName(29, "29.png")
        Me.ImageList1.Images.SetKeyName(30, "30.png")
        Me.ImageList1.Images.SetKeyName(31, "31.png")
        Me.ImageList1.Images.SetKeyName(32, "32.png")
        '
        'ImageList2
        '
        Me.ImageList2.ImageStream = CType(resources.GetObject("ImageList2.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList2.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList2.Images.SetKeyName(0, "0.png")
        Me.ImageList2.Images.SetKeyName(1, "1.png")
        Me.ImageList2.Images.SetKeyName(2, "2.png")
        Me.ImageList2.Images.SetKeyName(3, "3.png")
        Me.ImageList2.Images.SetKeyName(4, "4.png")
        Me.ImageList2.Images.SetKeyName(5, "5.png")
        Me.ImageList2.Images.SetKeyName(6, "6.png")
        Me.ImageList2.Images.SetKeyName(7, "7.png")
        Me.ImageList2.Images.SetKeyName(8, "8.png")
        Me.ImageList2.Images.SetKeyName(9, "9.png")
        Me.ImageList2.Images.SetKeyName(10, "10.png")
        Me.ImageList2.Images.SetKeyName(11, "11.png")
        Me.ImageList2.Images.SetKeyName(12, "12.png")
        Me.ImageList2.Images.SetKeyName(13, "13.png")
        Me.ImageList2.Images.SetKeyName(14, "14.png")
        Me.ImageList2.Images.SetKeyName(15, "15.png")
        Me.ImageList2.Images.SetKeyName(16, "16.png")
        Me.ImageList2.Images.SetKeyName(17, "17.png")
        Me.ImageList2.Images.SetKeyName(18, "18.png")
        Me.ImageList2.Images.SetKeyName(19, "19.png")
        Me.ImageList2.Images.SetKeyName(20, "20.png")
        Me.ImageList2.Images.SetKeyName(21, "21.png")
        Me.ImageList2.Images.SetKeyName(22, "22.png")
        Me.ImageList2.Images.SetKeyName(23, "23.png")
        Me.ImageList2.Images.SetKeyName(24, "24.png")
        Me.ImageList2.Images.SetKeyName(25, "25.png")
        Me.ImageList2.Images.SetKeyName(26, "26.png")
        Me.ImageList2.Images.SetKeyName(27, "27.png")
        Me.ImageList2.Images.SetKeyName(28, "28.png")
        Me.ImageList2.Images.SetKeyName(29, "29.png")
        Me.ImageList2.Images.SetKeyName(30, "30.png")
        Me.ImageList2.Images.SetKeyName(31, "31.png")
        Me.ImageList2.Images.SetKeyName(32, "32.png")
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(586, 557)
        Me.Controls.Add(Me.ZainView1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MainMenu)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MainMenu
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HardMon 2.0"
        Me.MainMenu.ResumeLayout(False)
        Me.MainMenu.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MainMenu As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveMonitoringData As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DarkModeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WidgetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AlwaysOnTopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MonitoringToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CPUToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GPUToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RAMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HDDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BatteryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NetworkToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ShowAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HardMonSDKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents LbLogStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ZainView1 As ZainView.ZainView
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents ImageList2 As System.Windows.Forms.ImageList
    Friend WithEvents Tema As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents refreshTimer As System.Windows.Forms.Timer
    Friend WithEvents AudioDeviceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
