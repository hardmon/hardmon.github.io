﻿Imports System.Threading
Imports HardEngine

Public Class Form1
    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            If Not DesignMode Then
                cp.ExStyle = cp.ExStyle Or &H2000000 ' WS_EX_COMPOSITED
                cp.ExStyle = cp.ExStyle Or &H80000 ' WS_EX_LAYERED (opsional)
            End If
            Return cp
        End Get
    End Property
    Public Sub UpdateDataThread()
        While Not stopThread
            Try
                ' Get fresh data
                Dim newData As New LatestMonitorData()
                monitor.Refresh()

                ' Ambil data hardware
                newData.CPUInfo = monitor.CPUInfos()
                newData.GPUInfo = monitor.GPUInfos()
                newData.RAMInfo = monitor.RAMInfos()
                newData.HDDInfo = monitor.HDDInfos()
                newData.SpeakerInfo = monitor.GetAudioInfos()

                ' Ambil data network
                newData.Networkinfo = monitor.GetNetworkInfos()

                ' Ambil data battery - TAMBAHKAN INI
                newData.BatteryInfo = monitor.BatteryInfos()

                ' Update latest data in a thread-safe way
                SyncLock dataLock
                    latestData = newData
                End SyncLock

                ' Signal UI to update
                Me.Invoke(New MethodInvoker(AddressOf UpdateTreeViewNeeded))

                Thread.Sleep(1000)
            Catch ex As Exception
                Debug.WriteLine("Update thread error: " & ex.Message)
            End Try
        End While
    End Sub

    Private Sub UpdateTreeViewNeeded()
        ' This method is called from the UI thread via Invoke
        If Not ZainView1.IsDisposed Then
            UpdateTreeView()
        End If
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If widget Then
            e.Cancel = True ' Batalkan penutupan
            Me.Hide()       ' Sembunyikan Form1
            frmWCPU.Show()  ' Tampilkan widget
            Return
        End If

        ' Kalau widget = False, lanjut keluar
        monitor.NetworkStop()
        monitor.StopBatteryMonitoring()

        Dim tempPath As String = System.IO.Path.Combine(Application.StartupPath, "temp.h")
        If System.IO.File.Exists(tempPath) Then
            System.IO.File.Delete(tempPath)
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.MinimumSize = New Size(602, 596)
        MainGetData()
        If My.Settings.overview = "" Then
            frmOverview.Show()
        Else
            '
        End If

    End Sub

    Private Sub ZainView1_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles ZainView1.AfterSelect

    End Sub

    Private Sub ZainView1_BeforeSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles ZainView1.BeforeSelect
        e.Cancel = True
    End Sub

    Private Sub CPUToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CPUToolStripMenuItem.Click
        If CPUToolStripMenuItem.Checked Then
            CPUToolStripMenuItem.Checked = False
            ShowAllToolStripMenuItem.Checked = False
            expandall = False
            LbLogStatus.Text = "Monitoring Only CPU Disabled"
        Else
            expandall = True
            CPUToolStripMenuItem.Checked = True
            LbLogStatus.Text = "Monitoring Only CPU Enabled"
            If CPUToolStripMenuItem.Checked AndAlso GPUToolStripMenuItem.Checked AndAlso RAMToolStripMenuItem.Checked AndAlso HDDToolStripMenuItem.Checked AndAlso BatteryToolStripMenuItem.Checked AndAlso NetworkToolStripMenuItem.Checked AndAlso AudioDeviceToolStripMenuItem.Checked Then
                ShowAllToolStripMenuItem.Checked = True
            Else
                '
            End If
        End If
    End Sub

    Private Sub GPUToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GPUToolStripMenuItem.Click
        If GPUToolStripMenuItem.Checked Then
            GPUToolStripMenuItem.Checked = False
            ShowAllToolStripMenuItem.Checked = False
            expandall = False
            LbLogStatus.Text = "Monitoring Only GPU Disabled"
        Else
            expandall = True
            GPUToolStripMenuItem.Checked = True
            LbLogStatus.Text = "Monitoring Only GPU Enabled"
            If CPUToolStripMenuItem.Checked AndAlso GPUToolStripMenuItem.Checked AndAlso RAMToolStripMenuItem.Checked AndAlso HDDToolStripMenuItem.Checked AndAlso BatteryToolStripMenuItem.Checked AndAlso NetworkToolStripMenuItem.Checked AndAlso AudioDeviceToolStripMenuItem.Checked Then
                ShowAllToolStripMenuItem.Checked = True
            Else
                '
            End If
        End If
    End Sub

    Private Sub RAMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RAMToolStripMenuItem.Click
        If RAMToolStripMenuItem.Checked Then
            RAMToolStripMenuItem.Checked = False
            ShowAllToolStripMenuItem.Checked = False
            expandall = False
            LbLogStatus.Text = "Monitoring Only RAM Disabled"
        Else
            expandall = True
            RAMToolStripMenuItem.Checked = True
            LbLogStatus.Text = "Monitoring Only RAM Enabled"
            If CPUToolStripMenuItem.Checked AndAlso GPUToolStripMenuItem.Checked AndAlso RAMToolStripMenuItem.Checked AndAlso HDDToolStripMenuItem.Checked AndAlso BatteryToolStripMenuItem.Checked AndAlso NetworkToolStripMenuItem.Checked AndAlso AudioDeviceToolStripMenuItem.Checked Then
                ShowAllToolStripMenuItem.Checked = True
            Else
                '
            End If
        End If
    End Sub

    Private Sub HDDToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HDDToolStripMenuItem.Click
        If HDDToolStripMenuItem.Checked Then
            HDDToolStripMenuItem.Checked = False
            ShowAllToolStripMenuItem.Checked = False
            expandall = False
            LbLogStatus.Text = "Monitoring Only HDD Disabled"
        Else
            expandall = True
            HDDToolStripMenuItem.Checked = True
            LbLogStatus.Text = "Monitoring Only HDD Enabled"
            If CPUToolStripMenuItem.Checked AndAlso GPUToolStripMenuItem.Checked AndAlso RAMToolStripMenuItem.Checked AndAlso HDDToolStripMenuItem.Checked AndAlso BatteryToolStripMenuItem.Checked AndAlso NetworkToolStripMenuItem.Checked AndAlso AudioDeviceToolStripMenuItem.Checked Then
                ShowAllToolStripMenuItem.Checked = True
            Else
                '
            End If
        End If
    End Sub

    Private Sub BatteryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BatteryToolStripMenuItem.Click
        If BatteryToolStripMenuItem.Checked Then
            BatteryToolStripMenuItem.Checked = False
            ShowAllToolStripMenuItem.Checked = False
            expandall = False
            LbLogStatus.Text = "Monitoring Only Battery Disabled"
        Else
            expandall = True
            BatteryToolStripMenuItem.Checked = True
            LbLogStatus.Text = "Monitoring Only Battery Enabled"
            If CPUToolStripMenuItem.Checked AndAlso GPUToolStripMenuItem.Checked AndAlso RAMToolStripMenuItem.Checked AndAlso HDDToolStripMenuItem.Checked AndAlso BatteryToolStripMenuItem.Checked AndAlso NetworkToolStripMenuItem.Checked AndAlso AudioDeviceToolStripMenuItem.Checked Then
                ShowAllToolStripMenuItem.Checked = True
            Else
                '
            End If
        End If
    End Sub

    Private Sub NetworkToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NetworkToolStripMenuItem.Click
        If NetworkToolStripMenuItem.Checked Then
            NetworkToolStripMenuItem.Checked = False
            ShowAllToolStripMenuItem.Checked = False
            expandall = False
            LbLogStatus.Text = "Monitoring Only Network Disabled"
        Else
            expandall = True
            NetworkToolStripMenuItem.Checked = True
            LbLogStatus.Text = "Monitoring Only Network Enabled"
            If CPUToolStripMenuItem.Checked AndAlso GPUToolStripMenuItem.Checked AndAlso RAMToolStripMenuItem.Checked AndAlso HDDToolStripMenuItem.Checked AndAlso BatteryToolStripMenuItem.Checked AndAlso NetworkToolStripMenuItem.Checked AndAlso AudioDeviceToolStripMenuItem.Checked Then
                ShowAllToolStripMenuItem.Checked = True
            Else
                '
            End If
        End If
    End Sub

    Private Sub ShowAllToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowAllToolStripMenuItem.Click
        If ShowAllToolStripMenuItem.Checked Then
            ShowAllToolStripMenuItem.Checked = False
            CPUToolStripMenuItem.Checked = False
            GPUToolStripMenuItem.Checked = False
            RAMToolStripMenuItem.Checked = False
            HDDToolStripMenuItem.Checked = False
            BatteryToolStripMenuItem.Checked = False
            NetworkToolStripMenuItem.Checked = False
            AudioDeviceToolStripMenuItem.Checked = False
            CPUToolStripMenuItem.Enabled = True
            GPUToolStripMenuItem.Enabled = True
            RAMToolStripMenuItem.Enabled = True
            HDDToolStripMenuItem.Enabled = True
            BatteryToolStripMenuItem.Enabled = True
            NetworkToolStripMenuItem.Enabled = True
            AudioDeviceToolStripMenuItem.Enabled = True
            expandall = False
            LbLogStatus.Text = "Monitoring All Disabled"
        Else
            ShowAllToolStripMenuItem.Checked = True
            CPUToolStripMenuItem.Checked = True
            GPUToolStripMenuItem.Checked = True
            RAMToolStripMenuItem.Checked = True
            HDDToolStripMenuItem.Checked = True
            BatteryToolStripMenuItem.Checked = True
            NetworkToolStripMenuItem.Checked = True
            AudioDeviceToolStripMenuItem.Checked = True
            CPUToolStripMenuItem.Enabled = False
            GPUToolStripMenuItem.Enabled = False
            RAMToolStripMenuItem.Enabled = False
            HDDToolStripMenuItem.Enabled = False
            BatteryToolStripMenuItem.Enabled = False
            NetworkToolStripMenuItem.Enabled = False
            AudioDeviceToolStripMenuItem.Enabled = False
            expandall = True
            LbLogStatus.Text = "Monitoring All Enabled"
        End If
    End Sub

    Private Sub DarkModeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DarkModeToolStripMenuItem.Click
        If Tema.Text = "Light" Then
            DarkModeToolStripMenuItem.Checked = True
            ZainView1.BackColor = Color.FromArgb(66, 66, 66)
            ZainView1.ForeColor = Color.White
            ZainView1.ImageList = ImageList2
            Tema.Text = "Dark"
            My.Settings.SetColor = "Dark"
            My.Settings.Save()
            LbLogStatus.Text = "Dark Mode Enabled"
        ElseIf Tema.Text = "Dark" Then
            DarkModeToolStripMenuItem.Checked = False
            ZainView1.BackColor = Color.FromArgb(248, 249, 237)
            ZainView1.ForeColor = Color.Black
            ZainView1.ImageList = ImageList1
            Tema.Text = "Light"
            My.Settings.SetColor = "Light"
            My.Settings.Save()
            LbLogStatus.Text = "Dark Mode Disabled"
        End If
    End Sub

    Private Sub AlwaysOnTopToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AlwaysOnTopToolStripMenuItem.Click
        If AlwaysOnTopToolStripMenuItem.Checked Then
            Me.TopMost = False
            AlwaysOnTopToolStripMenuItem.Checked = False
            My.Settings.SetOnTop = ""
            My.Settings.Save()
            LbLogStatus.Text = "Always on top Disabled"
        Else
            Me.TopMost = True
            AlwaysOnTopToolStripMenuItem.Checked = True
            My.Settings.SetOnTop = "Top"
            My.Settings.Save()
            LbLogStatus.Text = "Always on top Enabled"
        End If
    End Sub

    Private Sub SaveMonitoringData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveMonitoringData.Click
        Dim saveFileDialog As New SaveFileDialog()
        saveFileDialog.Filter = "Text Files (*.txt)|*.txt"
        saveFileDialog.Title = "Save Monitoring Data"
        saveFileDialog.FileName = "HardMon_" & DateTime.Now.ToString("yyyy-MM-dd-hhmmss")
        If saveFileDialog.ShowDialog() = DialogResult.OK Then
            SaveTreeViewToFile(ZainView1, saveFileDialog.FileName)
            MessageBox.Show("Monitoring data is saved to " & saveFileDialog.FileName, "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        frmAbout.Show()
    End Sub

    Private Sub HardMonSDKToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HardMonSDKToolStripMenuItem.Click
        Try
            Process.Start("https://hardmon.github.io/sdk.html")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub WidgetToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WidgetToolStripMenuItem.Click
        Me.Hide()
        frmWCPU.Show()
        widget = True
        WidgetToolStripMenuItem.Checked = True
    End Sub

    Private Sub AudioDeviceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AudioDeviceToolStripMenuItem.Click
        If AudioDeviceToolStripMenuItem.Checked Then
            AudioDeviceToolStripMenuItem.Checked = False
            ShowAllToolStripMenuItem.Checked = False
            expandall = False
            LbLogStatus.Text = "Monitoring Only Audio Disabled"
        Else
            expandall = True
            AudioDeviceToolStripMenuItem.Checked = True
            LbLogStatus.Text = "Monitoring Only Audio Enabled"
            If CPUToolStripMenuItem.Checked AndAlso GPUToolStripMenuItem.Checked AndAlso RAMToolStripMenuItem.Checked AndAlso HDDToolStripMenuItem.Checked AndAlso BatteryToolStripMenuItem.Checked AndAlso NetworkToolStripMenuItem.Checked AndAlso AudioDeviceToolStripMenuItem.Checked Then
                ShowAllToolStripMenuItem.Checked = True
            Else
                '
            End If
        End If
    End Sub

    Private Sub MainMenu_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MainMenu.ItemClicked

    End Sub
End Class
