﻿Public Class frmOverview

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            My.Settings.overview = "Yes"
            My.Settings.Save()
        Else
            My.Settings.overview = ""
            My.Settings.Save()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Try
            Process.Start("https://hardmon.github.io/sdk.html")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.ActiveControl = Nothing
        Try
            Process.Start("https://paypal.me/AriSohandriPutraID")
            Me.Close()
        Catch ex As Exception
            '
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.ActiveControl = Nothing
        Try
            Process.Start("https://buymeacoffee.com/hardmon")
            Me.Close()
        Catch ex As Exception
            '
        End Try
    End Sub
End Class