﻿
Module OtherFunction

    Public widget As Boolean = False
    Public Sub SaveTreeViewToFile(ByVal treeView As TreeView, ByVal filePath As String)
        Using writer As New System.IO.StreamWriter(filePath)
            For Each node As TreeNode In treeView.Nodes
                WriteNodeToFile(node, writer, 0)
            Next
        End Using
    End Sub

    Private Sub WriteNodeToFile(ByVal node As TreeNode, ByVal writer As System.IO.StreamWriter, ByVal indentLevel As Integer)
        writer.WriteLine(New String(" "c, indentLevel * 2) & node.Text)
        For Each childNode As TreeNode In node.Nodes
            WriteNodeToFile(childNode, writer, indentLevel + 1)
        Next
    End Sub
End Module
