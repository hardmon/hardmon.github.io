﻿Imports HardEngine
Imports System.Management
Imports System.IO
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Text.RegularExpressions
Imports System.Windows.Forms
Imports System.Threading
Module GetData
    Public monitor As Hardware
    Public updateThread As Thread
    Public stopThread As Boolean = False
    Public dataLock As New Object()
    Public latestData As New LatestMonitorData()
    Public mbManufacturer As String
    Public mbProduct As String
    Public mbSerial As String
    Public biosManufacturer As String
    Public biosVersion As String
    Public tempdata As String
    Public clockdata As String
    Public memorydata As String
    Public expandall As Boolean = True
    Public expandnet As Boolean = True
    Public Class LatestMonitorData
        Public CPUInfo As List(Of Hardware.CPUInfo)
        Public GPUInfo As List(Of Hardware.GPUInfo)
        Public RAMInfo As List(Of Hardware.RAMInfo)
        Public HDDInfo As List(Of Hardware.HDDInfo)
        Public Networkinfo As List(Of Hardware.NetInfo)
        Public BatteryInfo As List(Of Hardware.BatteryInfo)
        Public SpeakerInfo As List(Of Hardware.AudioInfo)
    End Class
    Public Sub setColorView()
        If My.Settings.SetColor = "Light" Then
            Form1.DarkModeToolStripMenuItem.Checked = False
            Form1.ZainView1.BackColor = Color.FromArgb(248, 249, 237)
            Form1.ZainView1.ForeColor = Color.Black
            Form1.ZainView1.ImageList = Form1.ImageList1
            Form1.Tema.Text = "Light"
        ElseIf My.Settings.SetColor = "Dark" Then
            Form1.DarkModeToolStripMenuItem.Checked = True
            Form1.ZainView1.BackColor = Color.FromArgb(66, 66, 66)
            Form1.ZainView1.ForeColor = Color.White
            Form1.ZainView1.ImageList = Form1.ImageList2
            Form1.Tema.Text = "Dark"
        Else
            Form1.DarkModeToolStripMenuItem.Checked = False
            Form1.ZainView1.BackColor = Color.FromArgb(248, 249, 237)
            Form1.ZainView1.ForeColor = Color.Black
            Form1.ZainView1.ImageList = Form1.ImageList1
            Form1.Tema.Text = "Light"
        End If
    End Sub
    Public Sub CreateBatteryReport()
        Dim laporanPath As String = Path.Combine(Application.StartupPath, "temp.h")

        If File.Exists(laporanPath) Then
            Try
                File.Delete(laporanPath)
            Catch ex As Exception
                MessageBox.Show("Tidak bisa menghapus file lama: " & ex.Message)
                Exit Sub
            End Try
        End If

        Try
            Dim psi As New ProcessStartInfo()
            psi.FileName = "C:\Windows\Sysnative\cmd.exe" ' pakai sysnative agar tidak di-redirect
            psi.Arguments = "/c powercfg /batteryreport /output """ & laporanPath & """"
            psi.UseShellExecute = True
            psi.Verb = "runas"
            psi.WindowStyle = ProcessWindowStyle.Hidden

            Dim proc As Process = Process.Start(psi)
            proc.WaitForExit()

            If File.Exists(laporanPath) Then
                'MessageBox.Show("Laporan berhasil dibuat!")

            Else
                'MessageBox.Show("Laporan gagal dibuat meskipun proses selesai.")
            End If

        Catch ex As Exception
            MessageBox.Show("Kesalahan: " & ex.Message)
        End Try
    End Sub
    Public Sub setOnTop()
        If My.Settings.SetOnTop = "Top" Then
            Form1.TopMost = True
            Form1.AlwaysOnTopToolStripMenuItem.Checked = True
        Else
            Form1.TopMost = False
            Form1.AlwaysOnTopToolStripMenuItem.Checked = False
        End If
    End Sub

    Public Sub MainGetData()
        monitor = New Hardware
        setOnTop()
        setColorView()
        CreateBatteryReport()
        ' Mulai network monitoring
        monitor.NetworkMonitoring()

        monitor.StartBatteryMonitoring()

        Form1.refreshTimer.Interval = 1000 ' 1 second
        Form1.refreshTimer.Start()

        ' Start background thread for data collection
        updateThread = New Thread(AddressOf Form1.UpdateDataThread)
        updateThread.IsBackground = True
        updateThread.Start()

        Form1.ZainView1.HideSelection = True
    End Sub
  
   Public Sub UpdateTreeView()
        ' Store current scroll position
        Dim scrollPos As Integer = GetScrollPosition()

        ' Store expanded state of nodes
        Dim expandedNodes As New Dictionary(Of String, Boolean)
        SaveExpandedState(Form1.ZainView1.Nodes, expandedNodes)

        ' Store selected node (if any)
        Dim selectedNodePath As String = If(Form1.ZainView1.SelectedNode IsNot Nothing,
                                          GetNodePath(Form1.ZainView1.SelectedNode),
                                          String.Empty)

        ' Clear existing nodes
        Form1.ZainView1.BeginUpdate()
        Form1.ZainView1.Nodes.Clear()

        ' Add new nodes with latest data
        SyncLock dataLock
            ' System Info
            Dim searcher As New ManagementObjectSearcher("SELECT * FROM Win32_BaseBoard")

            For Each obj As ManagementObject In searcher.Get()
                Dim manufacturer As String = obj("Manufacturer").ToString()
                Dim product As String = obj("Product").ToString()
                mbManufacturer = manufacturer
                mbProduct = product
            Next

            Dim searcher1 As New ManagementObjectSearcher("SELECT * FROM Win32_BIOS")

            For Each obj As ManagementObject In searcher1.Get()
                Dim manufacturers As String = obj("Manufacturer").ToString()
                Dim versions As String = obj("SMBIOSBIOSVersion").ToString()
                biosManufacturer = manufacturers
                biosVersion = versions
            Next

            Dim systemNode As TreeNode = Form1.ZainView1.Nodes.Add(mbManufacturer & " (" & mbProduct & ")")
            systemNode.ImageIndex = 1
            systemNode.SelectedImageIndex = 1
            Dim systmnamenode As TreeNode = systemNode.Nodes.Add(biosManufacturer & "(" & biosVersion & ")")
            systmnamenode.ImageIndex = 2
            systmnamenode.SelectedImageIndex = 2
            Form1.Text = "HardMon 2.0 - [" & mbManufacturer & " (" & mbProduct & ")" & "]"

            ' CPU Information
            If latestData.CPUInfo IsNot Nothing AndAlso latestData.CPUInfo.Count > 0 Then
                If Form1.CPUToolStripMenuItem.Checked Then
                    For Each cpu In latestData.CPUInfo
                        Dim cpuNameNode As TreeNode = Form1.ZainView1.Nodes.Add(cpu.Name)
                        Dim cpuname As String = cpu.Name.ToLower
                        frmWCPU.lbcpu.Text = cpu.Name
                        cpuNameNode.ImageIndex = 3
                        cpuNameNode.SelectedImageIndex = 3

                        ' Add CPU Clock
                        If cpu.Clock.Count > 0 Then
                            Dim clockNode As TreeNode = cpuNameNode.Nodes.Add("Clock")
                            clockNode.ImageIndex = 4
                            clockNode.SelectedImageIndex = 4

                            For Each clock As String In cpu.Clock
                                Dim match As Match = Regex.Match(clock, "\d+([.,]\d+)?\s?MHz")
                                If match.Success Then
                                    frmWCPU.lbclock.Text = match.Value
                                End If
                                clockNode.Nodes.Add(clock)
                            Next
                        End If

                        ' Add CPU Load
                        If cpu.Load.Count > 0 Then
                            Dim loadNode As TreeNode = cpuNameNode.Nodes.Add("Load")
                            loadNode.ImageIndex = 5
                            loadNode.SelectedImageIndex = 5

                            For Each loads As String In cpu.Load
                                loadNode.Nodes.Add(loads)
                            Next
                        End If

                        ' Add CPU Temperature
                        If cpu.Temperature.Count > 0 Then
                            Dim tempNode As TreeNode = cpuNameNode.Nodes.Add("Temperature")
                            tempNode.ImageIndex = 6
                            tempNode.SelectedImageIndex = 6

                            For Each temp As String In cpu.Temperature
                                Dim match As Match = Regex.Match(temp, "\d+([.,]\d+)?\s?°C")
                                If match.Success Then
                                    frmWCPU.lbtemp.Text = match.Value
                                End If
                                tempNode.Nodes.Add(temp)
                            Next
                        End If

                        ' Add CPU Power
                        If cpu.Power.Count > 0 Then
                            Dim powerNode As TreeNode = cpuNameNode.Nodes.Add("Power")
                            powerNode.ImageIndex = 7
                            powerNode.SelectedImageIndex = 7
                            For Each power In cpu.Power
                                Dim match As Match = Regex.Match(power, "\d+([.,]\d+)?\s?W")
                                If match.Success Then
                                    frmWCPU.lbpower.Text = match.Value
                                End If
                                powerNode.Nodes.Add(power)
                            Next
                        End If

                        ' Add CPU Fans (NEW)
                        If cpu.Fans.Count > 0 Then
                            Dim fanNode As TreeNode = cpuNameNode.Nodes.Add("Fans")
                            fanNode.ImageIndex = 24 ' Assuming you have a fan icon at index 24
                            fanNode.SelectedImageIndex = 24
                            For Each fan In cpu.Fans
                                fanNode.Nodes.Add(fan)
                            Next
                        End If
                    Next
                End If
            Else
                Form1.CPUToolStripMenuItem.Visible = False
            End If

            ' GPU Information
            If latestData.GPUInfo IsNot Nothing AndAlso latestData.GPUInfo.Count > 0 Then
                If Form1.GPUToolStripMenuItem.Checked Then
                    For Each gpu In latestData.GPUInfo
                        Dim gpuNameNode As TreeNode = Form1.ZainView1.Nodes.Add(gpu.Name)
                        Dim gpuname As String = gpu.Name.ToLower
                        If gpuname.Contains("amd") Then
                            gpuNameNode.ImageIndex = 9
                            gpuNameNode.SelectedImageIndex = 9
                        ElseIf gpuname.Contains("radeon") Then
                            gpuNameNode.ImageIndex = 9
                            gpuNameNode.SelectedImageIndex = 9
                        ElseIf gpuname.Contains("nvidia") Then
                            gpuNameNode.ImageIndex = 10
                            gpuNameNode.SelectedImageIndex = 10
                        ElseIf gpuname.Contains("rtx") Then
                            gpuNameNode.ImageIndex = 10
                            gpuNameNode.SelectedImageIndex = 10
                        ElseIf gpuname.Contains("gtx") Then
                            gpuNameNode.ImageIndex = 10
                            gpuNameNode.SelectedImageIndex = 10
                        Else
                            gpuNameNode.ImageIndex = 8
                            gpuNameNode.SelectedImageIndex = 8
                        End If

                        ' Add GPU Load
                        If gpu.Load.Count > 0 Then
                            Dim loadNode As TreeNode = gpuNameNode.Nodes.Add("Load")
                            loadNode.ImageIndex = 5
                            loadNode.SelectedImageIndex = 5
                            For Each loads In gpu.Load
                                loadNode.Nodes.Add(loads)
                            Next
                        End If

                        ' Add GPU Temperature
                        If gpu.Temperature.Count > 0 Then
                            Dim tempNode As TreeNode = gpuNameNode.Nodes.Add("Temperature")
                            tempNode.ImageIndex = 6
                            tempNode.SelectedImageIndex = 6
                            For Each temp In gpu.Temperature
                                tempNode.Nodes.Add(temp)
                            Next
                        End If

                        ' Add GPU Clock
                        If gpu.Clock.Count > 0 Then
                            Dim clockNode As TreeNode = gpuNameNode.Nodes.Add("Clock")
                            clockNode.ImageIndex = 4
                            clockNode.SelectedImageIndex = 4
                            For Each clock In gpu.Clock
                                clockNode.Nodes.Add(clock)
                            Next
                        End If

                        ' Add GPU Memory
                        If gpu.Memory.Count > 0 Then
                            Dim memoryNode As TreeNode = gpuNameNode.Nodes.Add("Memory")
                            memoryNode.ImageIndex = 11
                            memoryNode.SelectedImageIndex = 11
                            For Each memory In gpu.Memory
                                memoryNode.Nodes.Add(memory)
                            Next
                        End If

                        ' Add GPU Fans (NEW)
                        If gpu.Fans.Count > 0 Then
                            Dim fanNode As TreeNode = gpuNameNode.Nodes.Add("Fans")
                            fanNode.ImageIndex = 24 ' Assuming you have a fan icon at index 24
                            fanNode.SelectedImageIndex = 24
                            For Each fan In gpu.Fans
                                fanNode.Nodes.Add(fan)
                            Next
                        End If
                    Next
                End If
            Else
                Form1.GPUToolStripMenuItem.Visible = False
            End If
           
            ' RAM Information (unchanged)
            If latestData.RAMInfo IsNot Nothing AndAlso latestData.RAMInfo.Count > 0 Then
                If Form1.RAMToolStripMenuItem.Checked Then
                    For Each ram In latestData.RAMInfo
                        Dim ramNameNode As TreeNode = Form1.ZainView1.Nodes.Add(ram.Name)
                        ramNameNode.ImageIndex = 11
                        ramNameNode.SelectedImageIndex = 11
                        If ram.Load.Count > 0 Then
                            Dim loadNode As TreeNode = ramNameNode.Nodes.Add("Load")
                            loadNode.ImageIndex = 5
                            loadNode.SelectedImageIndex = 5

                            For Each loads As String In ram.Load
                                Dim match As Match = Regex.Match(loads, "\d+([.,]\d+)?\s*%")
                                If match.Success Then
                                    frmWCPU.lbram.Text = match.Value
                                End If
                                loadNode.Nodes.Add(loads)
                            Next
                        End If

                        ' Add RAM Usage
                        If ram.Used.Count > 0 Then
                            Dim usageNode As TreeNode = ramNameNode.Nodes.Add("Usage")
                            usageNode.ImageIndex = 12
                            usageNode.SelectedImageIndex = 12
                            For Each used In ram.Used
                                usageNode.Nodes.Add(used)
                            Next
                            For Each avail In ram.Available
                                usageNode.Nodes.Add(avail)
                            Next
                            For Each total In ram.Total
                                usageNode.Nodes.Add(total)
                            Next
                        End If
                    Next
                End If
            Else
                Form1.RAMToolStripMenuItem.Visible = False
            End If

            ' HDD Information (unchanged)
            If latestData.HDDInfo IsNot Nothing AndAlso latestData.HDDInfo.Count > 0 Then
                If Form1.HDDToolStripMenuItem.Checked Then
                    For Each hdd In latestData.HDDInfo
                        Dim hddNameNode As TreeNode = Form1.ZainView1.Nodes.Add(hdd.Name)
                        hddNameNode.ImageIndex = 13
                        hddNameNode.SelectedImageIndex = 13
                        ' Add HDD Temperature
                        If hdd.Temperature.Count > 0 Then
                            Dim tempNode As TreeNode = hddNameNode.Nodes.Add("Temperature")
                            tempNode.ImageIndex = 6
                            tempNode.SelectedImageIndex = 6
                            For Each temp In hdd.Temperature
                                tempNode.Nodes.Add(temp)
                            Next
                        End If

                        ' Add HDD Usage
                        If hdd.Load.Count > 0 Then
                            Dim usageNode As TreeNode = hddNameNode.Nodes.Add("Usage")
                            usageNode.ImageIndex = 12
                            usageNode.SelectedImageIndex = 12
                            For Each loads In hdd.Load
                                Dim match As Match = Regex.Match(loads, "\d+([.,]\d+)?\s*%")
                                If match.Success Then
                                    frmWCPU.lbhdd.Text = match.Value
                                End If
                                usageNode.Nodes.Add(loads)
                            Next
                        End If

                        ' Add HDD Throughput
                        If hdd.Throughput.Count > 0 Then
                            Dim throughputNode As TreeNode = hddNameNode.Nodes.Add("Throughput")
                            throughputNode.ImageIndex = 14
                            throughputNode.SelectedImageIndex = 14
                            For Each throughput In hdd.Throughput
                                throughputNode.Nodes.Add(throughput)
                            Next
                        End If
                    Next
                End If
            Else
                Form1.HDDToolStripMenuItem.Visible = False
            End If
           
            If latestData.Networkinfo IsNot Nothing AndAlso latestData.Networkinfo.Count > 0 Then
                If Form1.NetworkToolStripMenuItem.Checked Then
                    For Each adapter In latestData.Networkinfo
                        Dim netNode As TreeNode = Form1.ZainView1.Nodes.Add(adapter.Name)
                        netNode.ImageIndex = 21
                        netNode.SelectedImageIndex = 21
                        Dim address As TreeNode = netNode.Nodes.Add("IP Address")
                        address.Nodes.Add(adapter.IPGateway)
                        address.Nodes.Add(adapter.IPLocal)
                        address.Nodes.Add(adapter.IPPublic)
                        address.ImageIndex = 31
                        address.SelectedImageIndex = 31
                        ' Add Download Information
                        If adapter.Download.Count > 0 Then
                            Dim downloadNode As TreeNode = netNode.Nodes.Add("Download")
                            downloadNode.ImageIndex = 22
                            downloadNode.SelectedImageIndex = 22
                            For Each download In adapter.Download
                                downloadNode.Nodes.Add(download)
                            Next
                        End If

                        ' Add Upload Information
                        If adapter.Upload.Count > 0 Then
                            Dim uploadNode As TreeNode = netNode.Nodes.Add("Upload")
                            uploadNode.ImageIndex = 23
                            uploadNode.SelectedImageIndex = 23
                            For Each upload In adapter.Upload
                                uploadNode.Nodes.Add(upload)
                            Next
                        End If

                        ' Add Throughput Information (jika ada)
                        If adapter.Throughput.Count > 0 Then
                            Dim throughputNode As TreeNode = netNode.Nodes.Add("Throughput")
                            throughputNode.ImageIndex = 14 ' Gunakan icon yang sesuai
                            throughputNode.SelectedImageIndex = 14
                            For Each throughput In adapter.Throughput
                                Dim match As Match = Regex.Match(throughput, "\d+([.,]\d+)?\s*(B|KB|MB|GB)/s", RegexOptions.IgnoreCase)
                                If match.Success Then
                                    frmWCPU.lbnet.Text = match.Value
                                End If
                                throughputNode.Nodes.Add(throughput)
                            Next
                        End If
                        If adapter.PacketsReceived.Count > 0 Then
                            Dim packetreceiveNode As TreeNode = netNode.Nodes.Add("Packets")
                            packetreceiveNode.ImageIndex = 27
                            packetreceiveNode.SelectedImageIndex = 27
                            For Each receive In adapter.PacketsReceived
                                packetreceiveNode.Nodes.Add(receive)
                            Next
                            For Each sends In adapter.PacketsSent
                                packetreceiveNode.Nodes.Add(sends)
                            Next
                        End If
                    Next
                    If expandnet Then
                        Form1.ZainView1.ExpandAll()
                        expandnet = False
                    End If
                End If
            Else
                Form1.NetworkToolStripMenuItem.Visible = False
            End If

            ' Battery Information (unchanged)
            If latestData.BatteryInfo IsNot Nothing AndAlso latestData.BatteryInfo.Count > 0 Then
                If Form1.BatteryToolStripMenuItem.Checked Then
                    For Each battery In latestData.BatteryInfo
                        Dim batteryNode As TreeNode = Form1.ZainView1.Nodes.Add(battery.Name & " (" & battery.Manufacturer & ")")
                        batteryNode.ImageIndex = 15 ' Icon battery
                        batteryNode.SelectedImageIndex = 15

                        ' Status
                        If Not String.IsNullOrEmpty(battery.Chemistry) Then
                            Dim chemNode As TreeNode = batteryNode.Nodes.Add("Chemistry")
                            chemNode.Nodes.Add(battery.Chemistry)
                            chemNode.ImageIndex = 16
                        End If

                        ' Status
                        If battery.Status.Count > 0 Then
                            Dim statusNode As TreeNode = batteryNode.Nodes.Add("Status")
                            statusNode.ImageIndex = 25
                            For Each status In battery.Status
                                statusNode.Nodes.Add(status)
                            Next
                        End If

                        ' Charge Percentage
                        If battery.ChargePercentage.Count > 0 Then
                            Dim percentNode As TreeNode = batteryNode.Nodes.Add("Charge Level")
                            percentNode.ImageIndex = 20
                            For Each percent In battery.ChargePercentage
                                percentNode.Nodes.Add(percent)
                            Next
                        End If

                        ' Capacity
                        If battery.DesignCapacity.Count > 0 Then
                            Dim capacityNode As TreeNode = batteryNode.Nodes.Add("Capacity")
                            capacityNode.ImageIndex = 19
                            For Each cap In battery.DesignCapacity
                                capacityNode.Nodes.Add(cap)
                            Next
                            For Each fullCap In battery.FullChargeCapacity
                                capacityNode.Nodes.Add(fullCap)
                            Next
                        End If

                        ' Health
                        If battery.Health.Count > 0 Then
                            Dim healthNode As TreeNode = batteryNode.Nodes.Add("Health")
                            healthNode.ImageIndex = 26
                            For Each health In battery.Health
                                healthNode.Nodes.Add(health)
                            Next
                        End If

                        ' Voltage
                        If battery.Voltage.Count > 0 Then
                            Dim voltageNode As TreeNode = batteryNode.Nodes.Add("Voltage")
                            voltageNode.ImageIndex = 7
                            For Each voltage In battery.Voltage

                                voltageNode.Nodes.Add(voltage)
                            Next
                        End If

                        ' Charge/Discharge Rate
                        If battery.ChargeRate.Count > 0 OrElse battery.DischargeRate.Count > 0 Then
                            Dim rateNode As TreeNode = batteryNode.Nodes.Add("Rate")
                            rateNode.ImageIndex = 17
                            For Each Rates In battery.ChargeRate
                                rateNode.Nodes.Add(Rates)
                            Next
                            For Each Rates In battery.DischargeRate
                                rateNode.Nodes.Add(Rates)
                            Next
                        End If
                    Next
                End If
            End If
            If latestData.SpeakerInfo IsNot Nothing AndAlso latestData.SpeakerInfo.Count > 0 Then
                If Form1.AudioDeviceToolStripMenuItem.Checked Then
                    For Each ad In latestData.SpeakerInfo
                        Dim audinode As TreeNode = Form1.ZainView1.Nodes.Add("(" & ad.Direction & ") " & ad.LongName)
                        If ad.Direction = "Speaker" Then
                            audinode.ImageIndex = 28
                            audinode.SelectedImageIndex = 28
                        ElseIf ad.Direction = "Microphone" Then
                            audinode.ImageIndex = 32
                            audinode.SelectedImageIndex = 32
                        End If

                        Dim isdefault As TreeNode = audinode.Nodes.Add("Status")
                        isdefault.Nodes.Add(ad.IsDefault)
                        isdefault.Nodes.Add(ad.IsMuted)
                        isdefault.ImageIndex = 30
                        isdefault.SelectedImageIndex = 30
                        Dim vol As TreeNode = audinode.Nodes.Add("Volume")
                        vol.Nodes.Add(ad.VolumePercent)
                        vol.ImageIndex = 29
                        vol.SelectedImageIndex = 29
                    Next
                Else
                    '
                End If
            Else
                Form1.AudioDeviceToolStripMenuItem.Visible = False
            End If
        End SyncLock

        ' Restore expanded state
        RestoreExpandedState(Form1.ZainView1.Nodes, expandedNodes)

        ' Restore selected node (if it still exists)
        If Not String.IsNullOrEmpty(selectedNodePath) Then
            Dim nodeToSelect As TreeNode = FindNodeByPath(Form1.ZainView1.Nodes, selectedNodePath)
            If nodeToSelect IsNot Nothing Then
                Form1.ZainView1.SelectedNode = nodeToSelect
            End If
        End If

        If expandall Then
            Form1.ZainView1.ExpandAll()
            expandall = False
        End If

        SetScrollPosition(scrollPos)
        Form1.ZainView1.EndUpdate()
    End Sub

    Private Sub SaveExpandedState(ByVal nodes As TreeNodeCollection, ByRef expandedNodes As Dictionary(Of String, Boolean))
        For Each node As TreeNode In nodes
            expandedNodes(GetNodePath(node)) = node.IsExpanded
            If node.Nodes.Count > 0 Then
                SaveExpandedState(node.Nodes, expandedNodes)
            End If
        Next
    End Sub

    Private Sub RestoreExpandedState(ByVal nodes As TreeNodeCollection, ByVal expandedNodes As Dictionary(Of String, Boolean))
        For Each node As TreeNode In nodes
            Dim path As String = GetNodePath(node)
            If expandedNodes.ContainsKey(path) AndAlso expandedNodes(path) Then
                node.Expand()
            End If
            If node.Nodes.Count > 0 Then
                RestoreExpandedState(node.Nodes, expandedNodes)
            End If
        Next
    End Sub

    Private Function GetNodePath(ByVal node As TreeNode) As String
        Dim path As String = node.Text
        Dim parent As TreeNode = node.Parent
        While parent IsNot Nothing
            path = parent.Text & "/" & path
            parent = parent.Parent
        End While
        Return path
    End Function

    Private Function FindNodeByPath(ByVal nodes As TreeNodeCollection, ByVal path As String) As TreeNode
        Dim parts() As String = path.Split("/"c)
        If parts.Length = 0 Then Return Nothing

        Dim currentNodes As TreeNodeCollection = nodes
        Dim foundNode As TreeNode = Nothing

        For Each part As String In parts
            foundNode = Nothing
            For Each node As TreeNode In currentNodes
                If node.Text = part Then
                    foundNode = node
                    currentNodes = node.Nodes
                    Exit For
                End If
            Next
            If foundNode Is Nothing Then Exit For
        Next

        Return foundNode
    End Function


    Private Declare Auto Function GetScrollPos Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal nBar As Integer) As Integer
    Private Declare Auto Function SetScrollPos Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal nBar As Integer, ByVal nPos As Integer, ByVal bRedraw As Boolean) As Integer
    Private Declare Auto Function SendMessage Lib "user32.dll" Alias "SendMessageA" (ByVal hWnd As IntPtr, ByVal msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer

    Private Const WM_VSCROLL As Integer = &H115
    Private Const SB_THUMBPOSITION As Integer = 4
    Private Const SB_VERT As Integer = 1

    Private Function GetScrollPosition() As Integer
        Return GetScrollPos(Form1.ZainView1.Handle, SB_VERT)
    End Function

    Private Sub SetScrollPosition(ByVal position As Integer)
        SetScrollPos(Form1.ZainView1.Handle, SB_VERT, position, True)
        SendMessage(Form1.ZainView1.Handle, WM_VSCROLL, SB_THUMBPOSITION + &H10000 * position, 0)
    End Sub
End Module
