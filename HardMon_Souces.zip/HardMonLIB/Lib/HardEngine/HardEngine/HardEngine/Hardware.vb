﻿Imports System
Imports OpenHardwareMonitor.Hardware
Imports System.Globalization
Imports System.Management
Imports System.Text.RegularExpressions
Imports System.Threading
Imports System.Net.NetworkInformation
Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports NAudio.CoreAudioApi
Imports System.Collections.Generic
Imports System.Runtime.InteropServices

Public Class Hardware
    <StructLayout(LayoutKind.Sequential)> _
    Public Structure SYSTEM_POWER_STATUS
        Public ACLineStatus As Byte
        Public BatteryFlag As Byte
        Public BatteryLifePercent As Byte
        Public Reserved1 As Byte
        Public BatteryLifeTime As Integer
        Public BatteryFullLifeTime As Integer
    End Structure

    <DllImport("kernel32.dll")> _
    Public Shared Function GetSystemPowerStatus(ByRef sps As SYSTEM_POWER_STATUS) As Boolean
    End Function

    Private computer As Computer
    Public ActiveAdapters As ArrayList = New ArrayList()

    Private counters As ArrayList = New ArrayList()
    Private monitorThread As Thread = Nothing
    Private running As Boolean = False
    Private Function FormatLabelValue(ByVal label As String, ByVal value As String, Optional ByVal labelWidth As Integer = 30, Optional ByVal valueWidth As Integer = 15) As String
        label = label.Trim()
        Return label.PadRight(labelWidth) & " " & value.PadRight(valueWidth)
    End Function

    Private Function GetFormattedSensorValue(ByVal sensor As ISensor, ByVal valueFormat As String, ByVal unit As String) As String
        sensor.Hardware.Update()

        Dim currentValue As String = "N/A" & " " & unit
        Dim maxValue As String = "N/A" & " " & unit

        If sensor.Value.HasValue Then
            currentValue = sensor.Value.Value.ToString(valueFormat) & " " & unit
        End If

        If sensor.Max.HasValue Then
            maxValue = sensor.Max.Value.ToString(valueFormat) & " " & unit
        End If

        Return currentValue.PadRight(15) & "  Max: " & maxValue
    End Function

    Private Function FormatLabelWithSensor(ByVal sensor As ISensor, ByVal label As String,
                                         ByVal valueFormat As String, ByVal unit As String,
                                         Optional ByVal labelWidth As Integer = 30) As String
        label = label.Trim()
        Dim formattedValue As String = GetFormattedSensorValue(sensor, valueFormat, unit)
        Return label.PadRight(labelWidth) & formattedValue
    End Function
    Public Class CPUInfo
        Public Property Name As String
        Public Property Clock As New List(Of String)
        Public Property Temperature As New List(Of String)
        Public Property Power As New List(Of String)
        Public Property Load As New List(Of String)
        Public Property Voltage As New List(Of String)
        Public Property Energy As New List(Of String)
        Public Property Frequency As New List(Of String)
        Public Property BusSpeed As New List(Of String)
        Public Property Fans As New List(Of String)
    End Class
    Public Class GPUInfo
        Public Property Name As String
        Public Property Voltage As New List(Of String)
        Public Property Temperature As New List(Of String)
        Public Property Load As New List(Of String)
        Public Property Clock As New List(Of String)
        Public Property Fans As New List(Of String)
        Public Property Power As New List(Of String)
        Public Property Memory As New List(Of String)
        Public Property CoreVoltage As New List(Of String)
        Public Property FrameBufferLoad As New List(Of String)
        Public Property VideoEngineLoad As New List(Of String)
        Public Property BusInterfaceLoad As New List(Of String)
    End Class
    Public Class RAMInfo
        Public Property Name As String
        Public Property Load As New List(Of String)
        Public Property Used As New List(Of String)
        Public Property Available As New List(Of String)
        Public Property Total As New List(Of String)
        Public Property VirtualMemory As New List(Of String)
        Public Property PhysicalMemory As New List(Of String)
        Public Property MemoryControllerLoad As New List(Of String)
    End Class

    Public Class HDDInfo
        Public Property Name As String
        Public Property Temperature As New List(Of String)
        Public Property Load As New List(Of String)
        Public Property Throughput As New List(Of String)
        Public Property Data As New List(Of String)
        Public Property PowerOnTime As New List(Of String)
        Public Property RemainingLife As New List(Of String)
        Public Property PowerCycleCount As New List(Of String)
    End Class

    Public Class NetInfo
        Public Property Name As String
        Public Property IPGateway As String
        Public Property IPLocal As String
        Public Property IPPublic As String
        Public Property Download As New List(Of String)
        Public Property Upload As New List(Of String)
        Public Property Throughput As New List(Of String)
        Public Property PacketsReceived As New List(Of String)
        Public Property PacketsSent As New List(Of String)
    End Class
    Public Class BatteryInfo
        Public Property Name As String
        Public Property Manufacturer As String
        Public Property Chemistry As String
        Public Property DesignCapacity As New List(Of String)
        Public Property FullChargeCapacity As New List(Of String)
        Public Property CurrentCapacity As New List(Of String)
        Public Property ChargeRate As New List(Of String)
        Public Property DischargeRate As New List(Of String)
        Public Property ChargePercentage As New List(Of String)
        Public Property Status As New List(Of String)
        Public Property Voltage As New List(Of String)
        Public Property Health As New List(Of String)
    End Class
    Public Class AudioInfo
        Public LongName As String
        Public VolumePercent As String
        Public IsMuted As String
        Public IsDefault As String
        Public ID As String
        Public Direction As String
    End Class
    Public Sub New()
        computer = New Computer() With {
            .CPUEnabled = True,
            .MainboardEnabled = True,
            .HDDEnabled = True,
            .RAMEnabled = True,
            .GPUEnabled = True,
            .FanControllerEnabled = True
        }
        computer.Open()
    End Sub

    Public Function GetUserName() As String
        Return Environment.UserName
    End Function

    Public Function GetSystemName() As String
        Return Environment.MachineName
    End Function

    Public Function GetCPUName() As String
        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.CPU Then
                Return hardware.Name
            End If
        Next
        Return "Unknown CPU"
    End Function

    Public Function CPUInfos() As List(Of CPUInfo)
        Dim list As New List(Of CPUInfo)

        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.CPU Then
                hardware.Update()

                Dim info As New CPUInfo()
                info.Name = hardware.Name

                For Each sensor In hardware.Sensors
                    If sensor.SensorType = SensorType.Clock AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("core") Then
                            label = "Core #" & info.Clock.Count + 1
                            info.Clock.Add(FormatLabelWithSensor(sensor, label, "0.0", "MHz"))
                        ElseIf sensor.Name.ToLower().Contains("Bus") Then
                            label = "Bus Speed"
                            info.BusSpeed.Add(FormatLabelWithSensor(sensor, label, "0.0", "MHz"))
                        Else
                            info.Clock.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "MHz"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Load AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        Dim coreNumber As Integer

                        Dim coreMatch As Match = Regex.Match(sensor.Name, "Core (\d+)", RegexOptions.IgnoreCase)
                        If coreMatch.Success Then
                            coreNumber = Integer.Parse(coreMatch.Groups(1).Value)
                            label = "Core #" & coreNumber
                        ElseIf sensor.Name.ToLower().Contains("total") Then
                            label = "CPU Total"
                        ElseIf sensor.Name.ToLower().Contains("core") Then
                            coreNumber = info.Load.Count + 1
                            label = "Core #" & coreNumber
                        Else
                            label = sensor.Name
                        End If

                        info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                    ElseIf sensor.SensorType = SensorType.Temperature AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("core") Then
                            label = "Core #" & info.Temperature.Count + 1
                            info.Temperature.Add(FormatLabelWithSensor(sensor, label, "0.0", "°C"))
                        ElseIf sensor.Name.ToLower().Contains("package") Then
                            label = "Package"
                            info.Temperature.Add(FormatLabelWithSensor(sensor, label, "0.0", "°C"))
                        Else
                            info.Temperature.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "°C"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Power AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("package") Then
                            label = "Package Power"
                            info.Power.Add(FormatLabelWithSensor(sensor, label, "0.00", "W"))
                        ElseIf sensor.Name.ToLower().Contains("cores") Then
                            label = "Cores Power"
                            info.Power.Add(FormatLabelWithSensor(sensor, label, "0.00", "W"))
                        ElseIf sensor.Name.ToLower().Contains("graphics") Then
                            label = "Graphics Power"
                            info.Power.Add(FormatLabelWithSensor(sensor, label, "0.00", "W"))
                        Else
                            info.Power.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.00", "W"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Voltage AndAlso sensor.Value.HasValue Then
                        info.Voltage.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.000", "V"))
                    ElseIf sensor.SensorType = SensorType.Fan AndAlso sensor.Value.HasValue Then
                        ' Deteksi fan CPU
                        Dim label As String
                        If sensor.Name.ToLower().Contains("cpu fan") Then
                            label = "CPU Fan #" & (info.Fans.Count + 1).ToString()
                        ElseIf sensor.Name.ToLower().Contains("fan") Then
                            label = "Fan #" & (info.Fans.Count + 1).ToString()
                        Else
                            label = sensor.Name
                        End If
                        info.Fans.Add(FormatLabelWithSensor(sensor, label, "0", "RPM"))
                    End If
                Next

                list.Add(info)
            End If
        Next

        Return list
    End Function
    Public Function GPUInfos() As List(Of GPUInfo)
        Dim list As New List(Of GPUInfo)

        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.GpuNvidia OrElse hardware.HardwareType = HardwareType.GpuAti Then
                hardware.Update()
                Dim info As New GPUInfo()
                info.Name = hardware.Name

                For Each sensor In hardware.Sensors
                    If sensor.SensorType = SensorType.Temperature AndAlso sensor.Value.HasValue Then
                        info.Temperature.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "°C"))
                    ElseIf sensor.SensorType = SensorType.Load AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("gpu core") Then
                            label = "GPU Core Load"
                            info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().Contains("memory") Then
                            label = "Memory Controller Load"
                            info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().Contains("video engine") Then
                            label = "Video Engine Load"
                            info.VideoEngineLoad.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().Contains("frame buffer") Then
                            label = "Frame Buffer Load"
                            info.FrameBufferLoad.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().Contains("bus interface") Then
                            label = "Bus Interface Load"
                            info.BusInterfaceLoad.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        Else
                            info.Load.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "%"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Clock AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("core") Then
                            label = "GPU Core Clock"
                            info.Clock.Add(FormatLabelWithSensor(sensor, label, "0", "MHz"))
                        ElseIf sensor.Name.ToLower().Contains("memory") Then
                            label = "Memory Clock"
                            info.Clock.Add(FormatLabelWithSensor(sensor, label, "0", "MHz"))
                        ElseIf sensor.Name.ToLower().Contains("shader") Then
                            label = "Shader Clock"
                            info.Clock.Add(FormatLabelWithSensor(sensor, label, "0", "MHz"))
                        Else
                            info.Clock.Add(FormatLabelWithSensor(sensor, sensor.Name, "0", "MHz"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Power AndAlso sensor.Value.HasValue Then
                        info.Power.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.00", "W"))
                    ElseIf sensor.SensorType = SensorType.Fan AndAlso sensor.Value.HasValue Then
                        ' Deteksi fan GPU
                        Dim label As String
                        If sensor.Name.ToLower().Contains("fan") Then
                            label = "GPU Fan #" & (info.Fans.Count + 1).ToString()
                        Else
                            label = sensor.Name
                        End If
                        info.Fans.Add(FormatLabelWithSensor(sensor, label, "0", "RPM"))
                    ElseIf sensor.SensorType = SensorType.Voltage AndAlso sensor.Value.HasValue Then
                        If sensor.Name.ToLower().Contains("core") Then
                            Dim label As String = "Core Voltage"
                            info.CoreVoltage.Add(FormatLabelWithSensor(sensor, label, "0.000", "V"))
                        Else
                            info.Voltage.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.000", "V"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Data AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("memory used") Then
                            label = "Memory Used "
                            info.Memory.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        ElseIf sensor.Name.ToLower().Contains("memory free") Then
                            label = "Memory Free"
                            info.Memory.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        ElseIf sensor.Name.ToLower().Contains("memory total") Then
                            label = "Memory Total"
                            info.Memory.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        End If
                    End If
                Next

                list.Add(info)
            End If
        Next

        Return list
    End Function
    Public Function RAMInfos() As List(Of RAMInfo)
        Dim list As New List(Of RAMInfo)()

        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.RAM Then
                hardware.Update()

                Dim info As New RAMInfo()
                info.Name = hardware.Name

                Dim used As Nullable(Of Single) = Nothing
                Dim available As Nullable(Of Single) = Nothing
                Dim virtualUsed As Nullable(Of Single) = Nothing
                Dim virtualFree As Nullable(Of Single) = Nothing

                For Each sensor In hardware.Sensors
                    If sensor.SensorType = SensorType.Load AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("memory controller") Then
                            label = "Memory controller"
                            info.MemoryControllerLoad.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        Else
                            label = "Memory Load"
                            info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Data Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("used memory") Then
                            label = "Used memory"
                            used = sensor.Value
                            info.Used.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        ElseIf sensor.Name.ToLower().Contains("available memory") Then
                            label = "Available memory"
                            available = sensor.Value
                            info.Available.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        ElseIf sensor.Name.ToLower().Contains("virtual used memory") Then
                            label = "Virtual Used"
                            virtualUsed = sensor.Value
                            info.VirtualMemory.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        ElseIf sensor.Name.ToLower().Contains("virtual available memory") Then
                            label = "Virtual Available"
                            virtualFree = sensor.Value
                            info.VirtualMemory.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        End If
                    End If
                Next

                If used.HasValue AndAlso available.HasValue Then
                    Dim label As String = "Total Memory"
                    info.Total.Add(FormatLabelValue(label, (used.Value + available.Value).ToString("0.00") & " GB"))
                End If

                If virtualUsed.HasValue AndAlso virtualFree.HasValue Then
                    Dim label As String = "Virtual Total"
                    info.VirtualMemory.Add(FormatLabelValue(label, (virtualUsed.Value + virtualFree.Value).ToString("0.00") & " GB"))
                End If

                list.Add(info)
            End If
        Next

        Return list
    End Function
    Public Function HDDInfos() As List(Of HDDInfo)
        Dim list As New List(Of HDDInfo)

        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.HDD Then
                hardware.Update()
                Dim info As New HDDInfo
                info.Name = hardware.Name

                For Each sensor In hardware.Sensors
                    If sensor.SensorType = SensorType.Temperature AndAlso sensor.Value.HasValue Then
                        info.Temperature.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "°C"))
                    ElseIf sensor.SensorType = SensorType.Load AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("used space") Then
                            label = "Used Space"
                            info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().Contains("remaining life") Then
                            label = "Remaining Life"
                            info.RemainingLife.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Data AndAlso sensor.Value.HasValue Then
                        If sensor.Name.ToLower().Contains("data") Then
                            info.Data.Add(FormatLabelValue(sensor.Name, sensor.Value.Value.ToString("0.00") & " GB"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Throughput AndAlso sensor.Value.HasValue Then
                        info.Throughput.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.00", "MB/s"))
                    ElseIf sensor.SensorType = SensorType.Factor AndAlso sensor.Name.ToLower().Contains("power cycle count") AndAlso sensor.Value.HasValue Then
                        Dim label As String = "Power Cycles"
                        info.PowerCycleCount.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0")))
                    End If
                Next

                list.Add(info)
            End If
        Next

        Return list
    End Function
    Public Sub NetworkMonitoring()
        If monitorThread Is Nothing OrElse Not monitorThread.IsAlive Then
            counters.Clear()
            ActiveAdapters.Clear()

            Dim adapters As NetworkInterface() = NetworkInterface.GetAllNetworkInterfaces()
            Dim i As Integer
            For i = 0 To adapters.Length - 1
                Dim ni As NetworkInterface = adapters(i)
                If ni.OperationalStatus = OperationalStatus.Up AndAlso _
                   ni.NetworkInterfaceType <> NetworkInterfaceType.Loopback AndAlso _
                   ni.GetIPProperties().GatewayAddresses.Count > 0 Then
                    Try
                        Dim name As String = ni.Description
                        Dim downCounter As New PerformanceCounter("Network Interface", "Bytes Received/sec", name)
                        Dim upCounter As New PerformanceCounter("Network Interface", "Bytes Sent/sec", name)
                        Dim packetsReceived As New PerformanceCounter("Network Interface", "Packets Received/sec", name)
                        Dim packetsSent As New PerformanceCounter("Network Interface", "Packets Sent/sec", name)


                        downCounter.NextValue()
                        upCounter.NextValue()
                        packetsReceived.NextValue()
                        packetsSent.NextValue()

                        counters.Add(New Object() {name, downCounter, upCounter, packetsReceived, packetsSent})
                    Catch

                    End Try
                End If
            Next

            running = True
            monitorThread = New Thread(AddressOf MonitorAdapters)
            monitorThread.IsBackground = True
            monitorThread.Start()
        End If
    End Sub
    Public Function BatteryInfos() As List(Of BatteryInfo)
        Dim list As New List(Of BatteryInfo)()
        Dim info As New BatteryInfo()


        Try
            Dim searcher As New ManagementObjectSearcher("SELECT * FROM Win32_Battery")
            Dim foundBattery As Boolean = False

            For Each mo As ManagementObject In searcher.Get()
                foundBattery = True

                info.Name = If(mo("Name") IsNot Nothing, mo("Name").ToString(), "Battery")
                info.Manufacturer = If(mo("Manufacturer") IsNot Nothing, mo("Manufacturer").ToString(), "Unknown")

                Dim statusCode As String = If(mo("BatteryStatus") IsNot Nothing, mo("BatteryStatus").ToString(), "0")
                Dim statusText As String = GetBatteryStatusText(statusCode)
                info.Status.Add(FormatLabelValue("Status", statusText))

                Dim percent As String = "N/A"
                If mo("EstimatedChargeRemaining") IsNot Nothing Then
                    percent = mo("EstimatedChargeRemaining").ToString() & "%"
                Else
                    Dim sps As New SYSTEM_POWER_STATUS()
                    If GetSystemPowerStatus(sps) Then
                        If sps.BatteryLifePercent <> 255 Then
                            percent = sps.BatteryLifePercent.ToString() & "%"
                        End If
                    End If
                End If

                info.ChargePercentage.Add(FormatLabelValue("Charge", percent))
            Next

            If Not foundBattery Then
                Dim sps As New SYSTEM_POWER_STATUS()
                If GetSystemPowerStatus(sps) Then
                    Dim percent As String = If(sps.BatteryLifePercent <> 255, sps.BatteryLifePercent.ToString() & "%", "N/A")
                    info.ChargePercentage.Add(FormatLabelValue("Charge", percent))
                Else
                    info.ChargePercentage.Add(FormatLabelValue("Charge", "Error"))
                End If
            End If
        Catch ex As Exception

        End Try

        Try
            Dim searcherStatus As New ManagementObjectSearcher("ROOT\WMI", "SELECT * FROM BatteryStatus")
            For Each mo As ManagementObject In searcherStatus.Get()
                Dim voltage As String = "N/A"
                If mo("Voltage") IsNot Nothing Then
                    voltage = (Convert.ToInt32(mo("Voltage")) / 1000).ToString("0.0") & "V"
                End If
                info.Voltage.Add(FormatLabelValue("Voltage", voltage))

                If Convert.ToBoolean(mo("Charging")) Then
                    Dim chargeRate As String = "N/A"
                    If mo("ChargeRate") IsNot Nothing Then
                        chargeRate = (Convert.ToInt32(mo("ChargeRate")) / 1000).ToString("0.00") & "W"
                    End If
                    info.ChargeRate.Add(FormatLabelValue("Charge Rate", chargeRate))
                    info.DischargeRate.Add(FormatLabelValue("Discharge Rate", "-"))
                ElseIf Convert.ToBoolean(mo("Discharging")) Then
                    Dim dischargeRate As String = "N/A"
                    If mo("DischargeRate") IsNot Nothing Then
                        dischargeRate = (Convert.ToInt32(mo("DischargeRate")) / 1000).ToString("0.00") & "W"
                    End If
                    info.DischargeRate.Add(FormatLabelValue("Discharge Rate", dischargeRate))
                    info.ChargeRate.Add(FormatLabelValue("Charge Rate", "-"))
                End If
            Next
        Catch ex As Exception
            Debug.WriteLine("WMI BatteryStatus error: " & ex.Message)
        End Try


        If File.Exists(batteryReportPath) Then
            Try
                Dim htmlContent As String = File.ReadAllText(batteryReportPath)


                info.Manufacturer = ParseHtmlValue(htmlContent, "MANUFACTURER", info.Manufacturer)

                Dim chemistry As String = ParseHtmlValue(htmlContent, "CHEMISTRY")
                info.Chemistry = GetChemistryName(chemistry)

                Dim designCap As String = ParseHtmlValue(htmlContent, "DESIGN CAPACITY", " mWh")
                info.DesignCapacity.Add(FormatLabelValue("Design Capacity", designCap))

                Dim fullCap As String = ParseHtmlValue(htmlContent, "FULL CHARGE CAPACITY", " mWh")
                info.FullChargeCapacity.Add(FormatLabelValue("Full Charge", fullCap))


                If designCap <> "N/A" AndAlso fullCap <> "N/A" Then
                    Dim designMatch As Match = Regex.Match(designCap, "[\d\.]+")
                    Dim fullMatch As Match = Regex.Match(fullCap, "[\d\.]+")

                    If designMatch.Success AndAlso fullMatch.Success Then
                        Dim designVal As Double = Double.Parse(designMatch.Value)
                        Dim fullVal As Double = Double.Parse(fullMatch.Value)
                        Dim health As String = (fullVal / designVal * 100).ToString("0.0") & "%"
                        info.Health.Add(FormatLabelValue("Health", health))
                    End If
                End If

            Catch ex As Exception
                Debug.WriteLine("HTML parsing error: " & ex.Message)
            End Try
        End If

        list.Add(info)
        Return list
    End Function
    Public Function GetAudioInfos() As List(Of AudioInfo)
        Dim audioList As New List(Of AudioInfo)()

        Try
            Dim enumerator As New MMDeviceEnumerator()

            Dim defaultOutput As MMDevice = enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia)
            Dim outputDevices = enumerator.EnumerateAudioEndPoints(DataFlow.Render, DeviceState.Active)

            For Each device As MMDevice In outputDevices
                Dim info As New AudioInfo()
                info.LongName = device.DeviceFriendlyName
                info.VolumePercent = FormatLabelValue("Current", CInt(device.AudioEndpointVolume.MasterVolumeLevelScalar * 100) & "%")
                info.IsMuted = FormatLabelValue("Muted", If(device.AudioEndpointVolume.Mute, "Yes", "No"))
                info.IsDefault = FormatLabelValue("Default", If(device.ID = defaultOutput.ID, "Yes", "No"))
                info.ID = device.ID
                info.Direction = "Speaker"
                audioList.Add(info)
            Next

            Dim defaultInput As MMDevice = enumerator.GetDefaultAudioEndpoint(DataFlow.Capture, Role.Multimedia)
            Dim inputDevices = enumerator.EnumerateAudioEndPoints(DataFlow.Capture, DeviceState.Active)

            For Each device As MMDevice In inputDevices
                Dim info As New AudioInfo()
                info.LongName = device.DeviceFriendlyName
                info.VolumePercent = FormatLabelValue("Current", CInt(device.AudioEndpointVolume.MasterVolumeLevelScalar * 100) & "%")
                info.IsMuted = FormatLabelValue("Muted", If(device.AudioEndpointVolume.Mute, "Yes", "No"))
                info.IsDefault = FormatLabelValue("Default", If(device.ID = defaultInput.ID, "Yes", "No"))
                info.ID = device.ID
                info.Direction = "Microphone"
                audioList.Add(info)
            Next

        Catch ex As Exception

        End Try

        Return audioList
    End Function


    Public Sub NetworkStop()
        running = False
        If Not monitorThread Is Nothing AndAlso monitorThread.IsAlive Then
            monitorThread.Join(1000)
            monitorThread = Nothing
        End If
    End Sub
    Private Sub MonitorAdapters()
        Do While running
            Dim tempList As New ArrayList()

            Dim i As Integer
            For i = 0 To counters.Count - 1
                Dim item As Object() = CType(counters(i), Object())
                Dim name As String = CStr(item(0))
                Dim downCounter As PerformanceCounter = CType(item(1), PerformanceCounter)
                Dim upCounter As PerformanceCounter = CType(item(2), PerformanceCounter)
                Dim packetsReceived As PerformanceCounter = CType(item(3), PerformanceCounter)
                Dim packetsSent As PerformanceCounter = CType(item(4), PerformanceCounter)

                Try
                    Dim downVal As Single = downCounter.NextValue()
                    Dim upVal As Single = upCounter.NextValue()
                    Dim packetsRecvVal As Single = packetsReceived.NextValue()
                    Dim packetsSentVal As Single = packetsSent.NextValue()
                    Dim gatewayIP As String = GetGatewayIP()
                    Dim localIP As String = GetLocalIP()
                    Dim publicIP As String = GetPublicIP()
                    Dim info As New NetInfo
                    info.Name = name
                    info.IPGateway = FormatLabelValue("Gateway", gatewayIP)
                    info.IPLocal = FormatLabelValue("Local", localIP)
                    info.IPPublic = FormatLabelValue("Public", publicIP)
                    info.Download.Add(FormatLabelValue("Download", FormatBytes(downVal) & "/s"))
                    info.Upload.Add(FormatLabelValue("Upload", FormatBytes(upVal) & "/s"))
                    info.Throughput.Add(FormatLabelValue("Total", FormatBytes(downVal + upVal) & "/s"))
                    info.PacketsReceived.Add(FormatLabelValue("Received", packetsRecvVal.ToString("0.00") & "/s"))
                    info.PacketsSent.Add(FormatLabelValue("Sent", packetsSentVal.ToString("0.00") & "/s"))

                    tempList.Add(info)
                Catch

                End Try
            Next

            SyncLock ActiveAdapters
                ActiveAdapters = tempList
            End SyncLock

            Thread.Sleep(1000)
        Loop
    End Sub
    Function GetLocalIP() As String
        Try
            Dim host As String = Dns.GetHostName()
            Dim ipEntry As IPHostEntry = Dns.GetHostEntry(host)

            For Each ip As IPAddress In ipEntry.AddressList
                If ip.AddressFamily = AddressFamily.InterNetwork Then
                    Return ip.ToString()
                End If
            Next
            Return "N/A"
        Catch ex As Exception
            Return "Gagal: " & ex.Message
        End Try
    End Function

    Function GetPublicIP() As String
        Try
            Dim client As New WebClient()
            Return client.DownloadString("http://ipinfo.io/ip").Trim()
        Catch ex As Exception
            Return "N/A"
        End Try
    End Function
    Function GetGatewayIP() As String
        Try
            Dim adapters() As NetworkInterface = NetworkInterface.GetAllNetworkInterfaces()
            For Each adapter As NetworkInterface In adapters
                If adapter.OperationalStatus = OperationalStatus.Up Then
                    Dim properties As IPInterfaceProperties = adapter.GetIPProperties()
                    Dim gateways As GatewayIPAddressInformationCollection = properties.GatewayAddresses
                    For Each gateway As GatewayIPAddressInformation In gateways
                        If gateway.Address.AddressFamily = AddressFamily.InterNetwork Then
                            Return gateway.Address.ToString()
                        End If
                    Next
                End If
            Next
            Return "N/A"
        Catch ex As Exception
            Return "N/A"
        End Try
    End Function
    Private Function FormatBytes(ByVal b As Single) As String
        If b >= 1024 * 1024 Then
            Return (b / 1024 / 1024).ToString("0.00") & " MB"
        ElseIf b >= 1024 Then
            Return (b / 1024).ToString("0.00") & " KB"
        Else
            Return b.ToString("0") & " B"
        End If
    End Function

    Private batteryReportPath As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "temp.h")
    Private batteryMonitoringThread As Thread = Nothing
    Private batteryMonitoringRunning As Boolean = False

    Public Sub StartBatteryMonitoring()
        If batteryMonitoringThread Is Nothing OrElse Not batteryMonitoringThread.IsAlive Then
            batteryMonitoringRunning = True
            batteryMonitoringThread = New Thread(AddressOf MonitorBattery)
            batteryMonitoringThread.IsBackground = True
            batteryMonitoringThread.Start()
        End If
    End Sub

    Public Sub StopBatteryMonitoring()
        batteryMonitoringRunning = False
        If batteryMonitoringThread IsNot Nothing Then
            batteryMonitoringThread.Join(1000)
            batteryMonitoringThread = Nothing
        End If
    End Sub

    Private Sub MonitorBattery()
        While batteryMonitoringRunning
            Try
                If Not File.Exists(batteryReportPath) Then

                    Thread.Sleep(1000)
                End If

                Thread.Sleep(5000)
            Catch ex As Exception
                Debug.WriteLine("Battery monitoring error: " & ex.Message)
                Thread.Sleep(10000)
            End Try
        End While
    End Sub



    Private Function ParseHtmlValue(ByVal html As String, ByVal fieldName As String, Optional ByVal defaultValue As String = "N/A", Optional ByVal suffix As String = "") As String
        Try
            Dim pattern As String = "<span[^>]*>" & fieldName & "</span>\s*</td>\s*<td[^>]*>([^<]+)"
            Dim match As Match = Regex.Match(html, pattern, RegexOptions.IgnoreCase)

            If match.Success Then

                Dim value As String = match.Groups(1).Value
                value = value.Trim()
                value = Regex.Replace(value, "\s+", " ")
                value = Regex.Replace(value, "<!--.*?-->", "")

                Debug.WriteLine("Found " & fieldName & ": " & value)

                Return value & suffix
            Else
                pattern = "<td[^>]*>\s*<span[^>]*>" & fieldName & "</span>\s*</td>\s*<td[^>]*>([^<]+)"
                match = Regex.Match(html, pattern, RegexOptions.IgnoreCase)

                If match.Success Then
                    Dim value As String = match.Groups(1).Value.Trim()
                    Debug.WriteLine("Found (alt) " & fieldName & ": " & value)
                    Return value & suffix
                End If
            End If

            Dim startTag As String = "<span class=""label"">" & fieldName & "</span></td><td>"
            Dim startIdx As Integer = html.IndexOf(startTag)
            If startIdx > 0 Then
                startIdx += startTag.Length
                Dim endIdx As Integer = html.IndexOf("<", startIdx)
                If endIdx > startIdx Then
                    Dim value As String = html.Substring(startIdx, endIdx - startIdx).Trim()
                    Debug.WriteLine("Found (substring) " & fieldName & ": " & value)
                    Return value & suffix
                End If
            End If

        Catch ex As Exception
            Debug.WriteLine("Error parsing " & fieldName & ": " & ex.Message)
        End Try

        Return defaultValue
    End Function

    Private Function GetChemistryName(ByVal chemistryCode As String) As String
        If String.IsNullOrEmpty(chemistryCode) Then
            Return "Unknown"
        End If
        Dim normalizedCode As String = chemistryCode.ToUpper()
        normalizedCode = Regex.Replace(normalizedCode, "[^A-Z]", "")

        Select Case normalizedCode
            Case "LION", "LIION", "LI"
                Return "Lithium Ion"
            Case "LIPO", "LIPO"
                Return "Lithium Polymer"
            Case "NICD", "NICD"
                Return "Nickel Cadmium"
            Case "NIMH", "NIMH"
                Return "Nickel Metal Hydride"
            Case Else
                Return chemistryCode
        End Select
    End Function

    Private Function GetBatteryStatusText(ByVal statusCode As String) As String
        Select Case statusCode
            Case "1"
                Return "Discharging"
            Case "2"
                Return "AC Power"
            Case "3"
                Return "Fully Charged"
            Case "4"
                Return "Low"
            Case "5"
                Return "Critical"
            Case "6"
                Return "Charging"
            Case "7"
                Return "Charging (High)"
            Case "8"
                Return "Charging (Low)"
            Case "9"
                Return "Charging (Critical)"
            Case "11"
                Return "Partially Charged"
            Case Else
                Return "Unknown"
        End Select
    End Function
    Public Function CoreCount() As Integer
        Dim count As Integer = 0
        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.CPU Then
                hardware.Update()
                For Each sensor In hardware.Sensors
                    If sensor.SensorType = SensorType.Temperature AndAlso sensor.Name.ToLower().Contains("core") Then
                        count += 1
                    End If
                Next
            End If
        Next
        Return count
    End Function
    Public Function GetNetworkInfos() As List(Of NetInfo)
        Dim list As New List(Of NetInfo)()
        SyncLock ActiveAdapters
            For Each adapter In ActiveAdapters
                list.Add(DirectCast(adapter, NetInfo))
            Next
        End SyncLock
        Return list
    End Function
    Public Sub Refresh()
        For Each hardware In computer.Hardware
            hardware.Update()
        Next
    End Sub
End Class