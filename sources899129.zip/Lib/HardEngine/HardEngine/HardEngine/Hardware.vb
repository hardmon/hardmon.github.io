﻿Imports System
Imports OpenHardwareMonitor.Hardware
Imports System.Globalization
Imports System.Management
Public Class Hardware
    Private computer As Computer

    Private Function FormatLabelValue(ByVal label As String, ByVal value As String, Optional ByVal labelWidth As Integer = 30, Optional ByVal valueWidth As Integer = 15) As String
        label = label.Trim()
        Return label.PadRight(labelWidth) & " " & value.PadRight(valueWidth)
    End Function

    Private Function GetFormattedSensorValue(ByVal sensor As ISensor, ByVal valueFormat As String, ByVal unit As String) As String
        ' Update hardware sebelum membaca sensor
        sensor.Hardware.Update()

        Dim currentValue As String = "N/A" & " " & unit
        Dim maxValue As String = "N/A" & " " & unit

        If sensor.Value.HasValue Then
            currentValue = sensor.Value.Value.ToString(valueFormat) & " " & unit
        End If

        If sensor.Max.HasValue Then
            maxValue = sensor.Max.Value.ToString(valueFormat) & " " & unit
        End If

        ' Format dengan padding yang tepat untuk alignment
        Return currentValue.PadRight(15) & "  Max: " & maxValue
    End Function

    Private Function FormatLabelWithSensor(ByVal sensor As ISensor, ByVal label As String,
                                         ByVal valueFormat As String, ByVal unit As String,
                                         Optional ByVal labelWidth As Integer = 30) As String
        label = label.Trim()
        Dim formattedValue As String = GetFormattedSensorValue(sensor, valueFormat, unit)
        Return label.PadRight(labelWidth) & formattedValue
    End Function



    Public Class RAMInfo
        Public Property Name As String
        Public Property Load As New List(Of String)
        Public Property Used As New List(Of String)
        Public Property Available As New List(Of String)
        Public Property Total As New List(Of String)
        Public Property VirtualMemory As New List(Of String)
        Public Property PhysicalMemory As New List(Of String)
        Public Property MemoryControllerLoad As New List(Of String)
    End Class

    Public Class HDDInfo
        Public Property Name As String
        Public Property Temperature As New List(Of String)
        Public Property Load As New List(Of String)
        Public Property Throughput As New List(Of String)
        Public Property Data As New List(Of String)
        Public Property PowerOnTime As New List(Of String)
        Public Property RemainingLife As New List(Of String)
        Public Property PowerCycleCount As New List(Of String)
    End Class

    Public Class CPUInfo
        Public Property Name As String
        Public Property Clock As New List(Of String)
        Public Property Temperature As New List(Of String)
        Public Property Power As New List(Of String)
        Public Property Load As New List(Of String)
        Public Property Voltage As New List(Of String)
        Public Property Energy As New List(Of String)
        Public Property Frequency As New List(Of String)
        Public Property BusSpeed As New List(Of String)
    End Class

    Public Class GPUInfo
        Public Property Name As String
        Public Property Voltage As New List(Of String)
        Public Property Temperature As New List(Of String)
        Public Property Load As New List(Of String)
        Public Property Clock As New List(Of String)
        Public Property Fan As New List(Of String)
        Public Property Power As New List(Of String)
        Public Property Memory As New List(Of String)
        Public Property CoreVoltage As New List(Of String)
        Public Property FrameBufferLoad As New List(Of String)
        Public Property VideoEngineLoad As New List(Of String)
        Public Property BusInterfaceLoad As New List(Of String)
    End Class

    Public Sub New()
        computer = New Computer() With {
            .CPUEnabled = True,
            .MainboardEnabled = True,
            .HDDEnabled = True,
            .RAMEnabled = True,
            .GPUEnabled = True,
            .FanControllerEnabled = True
        }
        computer.Open()
    End Sub

    Public Function GetUserName() As String
        Return Environment.UserName
    End Function

    Public Function GetSystemName() As String
        Return Environment.MachineName
    End Function

    Public Function GetCPUName() As String
        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.CPU Then
                Return hardware.Name
            End If
        Next
        Return "Unknown CPU"
    End Function

    Public Function RAMInfos() As List(Of RAMInfo)
        Dim list As New List(Of RAMInfo)()

        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.RAM Then
                hardware.Update()

                Dim info As New RAMInfo()
                info.Name = hardware.Name

                Dim used As Nullable(Of Single) = Nothing
                Dim available As Nullable(Of Single) = Nothing
                Dim virtualUsed As Nullable(Of Single) = Nothing
                Dim virtualFree As Nullable(Of Single) = Nothing

                For Each sensor In hardware.Sensors
                    If sensor.SensorType = SensorType.Load AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("memory controller") Then
                            label = "Memory controller"
                            info.MemoryControllerLoad.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        Else
                            label = "Memory Load"
                            info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Data Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("used memory") Then
                            label = "Used memory"
                            used = sensor.Value
                            info.Used.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        ElseIf sensor.Name.ToLower().Contains("available memory") Then
                            label = "Available memory"
                            available = sensor.Value
                            info.Available.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        ElseIf sensor.Name.ToLower().Contains("virtual used memory") Then
                            label = "Virtual Used"
                            virtualUsed = sensor.Value
                            info.VirtualMemory.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        ElseIf sensor.Name.ToLower().Contains("virtual available memory") Then
                            label = "Virtual Available"
                            virtualFree = sensor.Value
                            info.VirtualMemory.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        End If
                    End If
                Next

                If used.HasValue AndAlso available.HasValue Then
                    Dim label As String = "Total Memory"
                    info.Total.Add(FormatLabelValue(label, (used.Value + available.Value).ToString("0.00") & " GB"))
                End If

                If virtualUsed.HasValue AndAlso virtualFree.HasValue Then
                    Dim label As String = "Virtual Total"
                    info.VirtualMemory.Add(FormatLabelValue(label, (virtualUsed.Value + virtualFree.Value).ToString("0.00") & " GB"))
                End If

                list.Add(info)
            End If
        Next

        Return list
    End Function

    Public Function HDDInfos() As List(Of HDDInfo)
        Dim list As New List(Of HDDInfo)

        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.HDD Then
                hardware.Update()
                Dim info As New HDDInfo
                info.Name = hardware.Name

                For Each sensor In hardware.Sensors
                    If sensor.SensorType = SensorType.Temperature AndAlso sensor.Value.HasValue Then
                        info.Temperature.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "°C"))
                    ElseIf sensor.SensorType = SensorType.Load AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("used space") Then
                            label = "Used Space"
                            info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().Contains("remaining life") Then
                            label = "Remaining Life"
                            info.RemainingLife.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Data AndAlso sensor.Value.HasValue Then
                        If sensor.Name.ToLower().Contains("data") Then
                            info.Data.Add(FormatLabelValue(sensor.Name, sensor.Value.Value.ToString("0.00") & " GB"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Throughput AndAlso sensor.Value.HasValue Then
                        info.Throughput.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.00", "MB/s"))
                    ElseIf sensor.SensorType = SensorType.Factor AndAlso sensor.Name.ToLower().Contains("power cycle count") AndAlso sensor.Value.HasValue Then
                        Dim label As String = "Power Cycles"
                        info.PowerCycleCount.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0")))
                    End If
                Next

                list.Add(info)
            End If
        Next

        Return list
    End Function

    Public Function GPUInfos() As List(Of GPUInfo)
        Dim list As New List(Of GPUInfo)

        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.GpuNvidia OrElse hardware.HardwareType = HardwareType.GpuAti Then
                hardware.Update()
                Dim info As New GPUInfo()
                info.Name = hardware.Name

                For Each sensor In hardware.Sensors
                    If sensor.SensorType = SensorType.Temperature AndAlso sensor.Value.HasValue Then
                        info.Temperature.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "°C"))
                    ElseIf sensor.SensorType = SensorType.Load AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("gpu core") Then
                            label = "GPU Core Load"
                            info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().Contains("memory") Then
                            label = "Memory Controller Load"
                            info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().Contains("video engine") Then
                            label = "Video Engine Load"
                            info.VideoEngineLoad.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().Contains("frame buffer") Then
                            label = "Frame Buffer Load"
                            info.FrameBufferLoad.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().Contains("bus interface") Then
                            label = "Bus Interface Load"
                            info.BusInterfaceLoad.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        Else
                            info.Load.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "%"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Clock AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("core") Then
                            label = "GPU Core Clock"
                            info.Clock.Add(FormatLabelWithSensor(sensor, label, "0", "MHz"))
                        ElseIf sensor.Name.ToLower().Contains("memory") Then
                            label = "Memory Clock"
                            info.Clock.Add(FormatLabelWithSensor(sensor, label, "0", "MHz"))
                        ElseIf sensor.Name.ToLower().Contains("shader") Then
                            label = "Shader Clock"
                            info.Clock.Add(FormatLabelWithSensor(sensor, label, "0", "MHz"))
                        Else
                            info.Clock.Add(FormatLabelWithSensor(sensor, sensor.Name, "0", "MHz"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Power AndAlso sensor.Value.HasValue Then
                        info.Power.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.00", "W"))
                    ElseIf sensor.SensorType = SensorType.Fan AndAlso sensor.Value.HasValue Then
                        info.Fan.Add(FormatLabelWithSensor(sensor, sensor.Name, "0", "RPM"))
                    ElseIf sensor.SensorType = SensorType.Voltage AndAlso sensor.Value.HasValue Then
                        If sensor.Name.ToLower().Contains("core") Then
                            Dim label As String = "Core Voltage"
                            info.CoreVoltage.Add(FormatLabelWithSensor(sensor, label, "0.000", "V"))
                        Else
                            info.Voltage.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.000", "V"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Data AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("memory used") Then
                            label = "Memory Used "
                            info.Memory.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        ElseIf sensor.Name.ToLower().Contains("memory free") Then
                            label = "Memory Free"
                            info.Memory.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        ElseIf sensor.Name.ToLower().Contains("memory total") Then
                            label = "Memory Total"
                            info.Memory.Add(FormatLabelValue(label, sensor.Value.Value.ToString("0.00") & " GB"))
                        End If
                    End If
                Next

                list.Add(info)
            End If
        Next

        Return list
    End Function

    Public Function CPUInfos() As List(Of CPUInfo)
        Dim list As New List(Of CPUInfo)

        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.CPU Then
                hardware.Update()

                Dim info As New CPUInfo()
                info.Name = hardware.Name

                For Each sensor In hardware.Sensors
                    If sensor.SensorType = SensorType.Clock AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("core") Then
                            label = "Core #" & info.Clock.Count + 1
                            info.Clock.Add(FormatLabelWithSensor(sensor, label, "0.0", "MHz"))
                        ElseIf sensor.Name.ToLower().Contains("speed") Then
                            label = "Bus Speed"
                            info.BusSpeed.Add(FormatLabelWithSensor(sensor, label, "0.0", "MHz"))
                        Else
                            info.Clock.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "MHz"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Load AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().StartsWith("cpu total") OrElse sensor.Name.ToLower().Contains("total") Then
                            label = "CPU Total"
                            info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        ElseIf sensor.Name.ToLower().StartsWith("cpu core") OrElse sensor.Name.ToLower().Contains("core") Then
                            label = "Core #" & info.Load.Count + 1
                            info.Load.Add(FormatLabelWithSensor(sensor, label, "0.0", "%"))
                        Else
                            info.Load.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "%"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Temperature AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("core") Then
                            label = "Core #" & info.Temperature.Count + 1
                            info.Temperature.Add(FormatLabelWithSensor(sensor, label, "0.0", "°C"))
                        ElseIf sensor.Name.ToLower().Contains("package") Then
                            label = "Package"
                            info.Temperature.Add(FormatLabelWithSensor(sensor, label, "0.0", "°C"))
                        Else
                            info.Temperature.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.0", "°C"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Power AndAlso sensor.Value.HasValue Then
                        Dim label As String
                        If sensor.Name.ToLower().Contains("package") Then
                            label = "Package Power"
                            info.Power.Add(FormatLabelWithSensor(sensor, label, "0.00", "W"))
                        ElseIf sensor.Name.ToLower().Contains("cores") Then
                            label = "Cores Power"
                            info.Power.Add(FormatLabelWithSensor(sensor, label, "0.00", "W"))
                        ElseIf sensor.Name.ToLower().Contains("graphics") Then
                            label = "Graphics Power"
                            info.Power.Add(FormatLabelWithSensor(sensor, label, "0.00", "W"))
                        Else
                            info.Power.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.00", "W"))
                        End If
                    ElseIf sensor.SensorType = SensorType.Voltage AndAlso sensor.Value.HasValue Then
                        info.Voltage.Add(FormatLabelWithSensor(sensor, sensor.Name, "0.000", "V"))
                    End If
                Next

                list.Add(info)
            End If
        Next

        Return list
    End Function

    Public Function CoreCount() As Integer
        Dim count As Integer = 0
        For Each hardware In computer.Hardware
            If hardware.HardwareType = HardwareType.CPU Then
                hardware.Update()
                For Each sensor In hardware.Sensors
                    If sensor.SensorType = SensorType.Temperature AndAlso sensor.Name.ToLower().Contains("core") Then
                        count += 1
                    End If
                Next
            End If
        Next
        Return count
    End Function

    Public Sub Refresh()
        For Each hardware In computer.Hardware
            hardware.Update()
        Next
    End Sub
End Class
