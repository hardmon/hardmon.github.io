﻿Imports System.IO
Public Class frmAbout

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Try
            Process.Start(Path.Combine(Application.StartupPath, "License.txt"))
            Me.Close()
        Catch ex As Exception
            Me.Close()
        End Try

    End Sub
End Class