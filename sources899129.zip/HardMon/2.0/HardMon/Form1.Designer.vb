﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveMonitoringDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ZoomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DefaultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MediumToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LargeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DefaultToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DarkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutHardMonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.lbtip = New System.Windows.Forms.ToolStripLabel()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.refreshTimer = New System.Windows.Forms.Timer(Me.components)
        Me.ImageList2 = New System.Windows.Forms.ImageList(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ZainView1 = New HardMon.ZainView()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackgroundImage = Global.HardMon.My.Resources.Resources.mnu
        Me.MenuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuStrip1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ViewToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(607, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveMonitoringDataToolStripMenuItem, Me.ToolStripSeparator2, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(36, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'SaveMonitoringDataToolStripMenuItem
        '
        Me.SaveMonitoringDataToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.SaveMonitoringDataToolStripMenuItem.Image = Global.HardMon.My.Resources.Resources.icons8_save_16
        Me.SaveMonitoringDataToolStripMenuItem.Name = "SaveMonitoringDataToolStripMenuItem"
        Me.SaveMonitoringDataToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveMonitoringDataToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.SaveMonitoringDataToolStripMenuItem.Text = "Save Monitoring Data"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(227, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ZoomToolStripMenuItem, Me.ToolStripSeparator1, Me.ColorToolStripMenuItem})
        Me.ViewToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.ViewToolStripMenuItem.Text = "&View"
        '
        'ZoomToolStripMenuItem
        '
        Me.ZoomToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DefaultToolStripMenuItem, Me.MediumToolStripMenuItem, Me.LargeToolStripMenuItem})
        Me.ZoomToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ZoomToolStripMenuItem.Image = Global.HardMon.My.Resources.Resources.icons8_font_16
        Me.ZoomToolStripMenuItem.Name = "ZoomToolStripMenuItem"
        Me.ZoomToolStripMenuItem.Size = New System.Drawing.Size(105, 22)
        Me.ZoomToolStripMenuItem.Text = "Zoom"
        '
        'DefaultToolStripMenuItem
        '
        Me.DefaultToolStripMenuItem.Checked = True
        Me.DefaultToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.DefaultToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.DefaultToolStripMenuItem.Name = "DefaultToolStripMenuItem"
        Me.DefaultToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.DefaultToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.DefaultToolStripMenuItem.Text = "Default"
        '
        'MediumToolStripMenuItem
        '
        Me.MediumToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.MediumToolStripMenuItem.Name = "MediumToolStripMenuItem"
        Me.MediumToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.MediumToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.MediumToolStripMenuItem.Text = "Medium"
        '
        'LargeToolStripMenuItem
        '
        Me.LargeToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.LargeToolStripMenuItem.Name = "LargeToolStripMenuItem"
        Me.LargeToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.LargeToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.LargeToolStripMenuItem.Text = "Large"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(102, 6)
        '
        'ColorToolStripMenuItem
        '
        Me.ColorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DefaultToolStripMenuItem1, Me.DarkToolStripMenuItem})
        Me.ColorToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ColorToolStripMenuItem.Image = Global.HardMon.My.Resources.Resources.icons8_themes_16
        Me.ColorToolStripMenuItem.Name = "ColorToolStripMenuItem"
        Me.ColorToolStripMenuItem.Size = New System.Drawing.Size(105, 22)
        Me.ColorToolStripMenuItem.Text = "Color"
        '
        'DefaultToolStripMenuItem1
        '
        Me.DefaultToolStripMenuItem1.Checked = True
        Me.DefaultToolStripMenuItem1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.DefaultToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.DefaultToolStripMenuItem1.Name = "DefaultToolStripMenuItem1"
        Me.DefaultToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.DefaultToolStripMenuItem1.Size = New System.Drawing.Size(140, 22)
        Me.DefaultToolStripMenuItem1.Text = "Light"
        '
        'DarkToolStripMenuItem
        '
        Me.DarkToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.DarkToolStripMenuItem.Name = "DarkToolStripMenuItem"
        Me.DarkToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.DarkToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.DarkToolStripMenuItem.Text = "Dark"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutHardMonToolStripMenuItem})
        Me.HelpToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'AboutHardMonToolStripMenuItem
        '
        Me.AboutHardMonToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.AboutHardMonToolStripMenuItem.Image = Global.HardMon.My.Resources.Resources.icons8_info_16
        Me.AboutHardMonToolStripMenuItem.Name = "AboutHardMonToolStripMenuItem"
        Me.AboutHardMonToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.AboutHardMonToolStripMenuItem.Text = "About HardMon"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackgroundImage = Global.HardMon.My.Resources.Resources.mnu
        Me.ToolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbtip})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 490)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(607, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'lbtip
        '
        Me.lbtip.Enabled = False
        Me.lbtip.Name = "lbtip"
        Me.lbtip.Size = New System.Drawing.Size(264, 22)
        Me.lbtip.Text = "Dark Themes (CTRL + D) /or Light Themes (CTRL + L)"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "no.png")
        Me.ImageList1.Images.SetKeyName(1, "proc.png")
        Me.ImageList1.Images.SetKeyName(2, "clock (1).png")
        Me.ImageList1.Images.SetKeyName(3, "sand-clock.png")
        Me.ImageList1.Images.SetKeyName(4, "high-temperature.png")
        Me.ImageList1.Images.SetKeyName(5, "high-voltage.png")
        Me.ImageList1.Images.SetKeyName(6, "gpu (1).png")
        Me.ImageList1.Images.SetKeyName(7, "ram (1).png")
        Me.ImageList1.Images.SetKeyName(8, "hard-disk.png")
        Me.ImageList1.Images.SetKeyName(9, "pie-chart (1).png")
        Me.ImageList1.Images.SetKeyName(10, "performance.png")
        Me.ImageList1.Images.SetKeyName(11, "motherboard (2).png")
        Me.ImageList1.Images.SetKeyName(12, "microcontroller.png")
        '
        'refreshTimer
        '
        '
        'ImageList2
        '
        Me.ImageList2.ImageStream = CType(resources.GetObject("ImageList2.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList2.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList2.Images.SetKeyName(0, "no.png")
        Me.ImageList2.Images.SetKeyName(1, "proc.png")
        Me.ImageList2.Images.SetKeyName(2, "clock (1).png")
        Me.ImageList2.Images.SetKeyName(3, "sand-clock.png")
        Me.ImageList2.Images.SetKeyName(4, "high-temperature.png")
        Me.ImageList2.Images.SetKeyName(5, "high-voltage.png")
        Me.ImageList2.Images.SetKeyName(6, "gpu (1).png")
        Me.ImageList2.Images.SetKeyName(7, "hard-disk.png")
        Me.ImageList2.Images.SetKeyName(8, "ram (1).png")
        Me.ImageList2.Images.SetKeyName(9, "pie-chart (1).png")
        Me.ImageList2.Images.SetKeyName(10, "performance.png")
        Me.ImageList2.Images.SetKeyName(11, "motherboard (2).png")
        Me.ImageList2.Images.SetKeyName(12, "microcontroller.png")
        '
        'Timer1
        '
        '
        'ZainView1
        '
        Me.ZainView1.BackColor = System.Drawing.Color.White
        Me.ZainView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ZainView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ZainView1.Font = New System.Drawing.Font("Consolas", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZainView1.Location = New System.Drawing.Point(0, 24)
        Me.ZainView1.Name = "ZainView1"
        Me.ZainView1.ShowPlusMinus = False
        Me.ZainView1.Size = New System.Drawing.Size(607, 466)
        Me.ZainView1.TabIndex = 2
        Me.ZainView1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(607, 515)
        Me.Controls.Add(Me.ZainView1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HardMon"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ZainView1 As HardMon.ZainView
    Friend WithEvents SaveMonitoringDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ZoomToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DefaultToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MediumToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LargeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DefaultToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DarkToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents refreshTimer As System.Windows.Forms.Timer
    Friend WithEvents ImageList2 As System.Windows.Forms.ImageList
    Friend WithEvents AboutHardMonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lbtip As System.Windows.Forms.ToolStripLabel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class
