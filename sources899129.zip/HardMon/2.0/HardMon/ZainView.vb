﻿Public Class ZainView
    Inherits TreeView

    Public Sub New()
        ' Aktifkan double buffering dan optimasi painting
        Me.SetStyle(ControlStyles.OptimizedDoubleBuffer Or _
                    ControlStyles.AllPaintingInWmPaint Or _
                    ControlStyles.ResizeRedraw, True)
        Me.UpdateStyles()
    End Sub

    Protected Overrides Sub OnHandleCreated(ByVal e As EventArgs)
        MyBase.OnHandleCreated(e)

        ' Aktifkan double buffering native (jika tersedia)
        Try
            Dim tvType As Type = Me.GetType()
            Dim pi As Reflection.PropertyInfo = tvType.GetProperty("DoubleBuffered",
                Reflection.BindingFlags.Instance Or Reflection.BindingFlags.NonPublic)
            pi.SetValue(Me, True, Nothing)
        Catch
            ' Fallback jika refleksi gagal
        End Try
    End Sub

    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            cp.Style = cp.Style And Not &H200000 ' WS_VSCROLL
            cp.Style = cp.Style And Not &H100000 ' WS_HSCROLL
            Return cp
        End Get
    End Property

    ' Blokir pesan WM_ERASEBKGND sepenuhnya
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = &H14 Then ' WM_ERASEBKGND
            m.Result = IntPtr.Zero
            Return
        End If
        MyBase.WndProc(m)
    End Sub
End Class